package thelostsoulsyeyeye.client.model;

import net.minecraft.client.animation.AnimationChannel;
import net.minecraft.client.animation.Keyframe;
import net.minecraft.client.animation.KeyframeAnimations;

/** Tiny helpers so the keyframe tables below read like tables. Angles are in degrees. */
final class Anim {
	private Anim() {}

	/** smooth keyframe */
	static Keyframe r(float time, float x, float y, float z) {
		return new Keyframe(time, KeyframeAnimations.degreeVec(x, y, z), AnimationChannel.Interpolations.CATMULLROM);
	}

	/** hard keyframe: the pose snaps linearly, with no easing. Used for twitches. */
	static Keyframe snap(float time, float x, float y, float z) {
		return new Keyframe(time, KeyframeAnimations.degreeVec(x, y, z), AnimationChannel.Interpolations.LINEAR);
	}

	static Keyframe p(float time, float x, float y, float z) {
		return new Keyframe(time, KeyframeAnimations.posVec(x, y, z), AnimationChannel.Interpolations.CATMULLROM);
	}

	static AnimationChannel rot(Keyframe... frames) {
		return new AnimationChannel(AnimationChannel.Targets.ROTATION, frames);
	}

	static AnimationChannel pos(Keyframe... frames) {
		return new AnimationChannel(AnimationChannel.Targets.POSITION, frames);
	}
}
