package thelostsoulsyeyeye.client.render;

import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import thelostsoulsyeyeye.Thelostsouls;
import thelostsoulsyeyeye.client.ClientFractureState;
import thelostsoulsyeyeye.world.TheirWorld;

/** Screen-space effects: a creeping vignette, the white flash of the crack, the red grip of the tentacle, and fades to/from black. */
public final class HudOverlay {
	private HudOverlay() {}

	private static final ResourceLocation VIGNETTE = Thelostsouls.id("textures/misc/vignette.png");

	public static void render(GuiGraphics graphics, float tickDelta) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null) {
			return;
		}
		int w = mc.getWindow().getGuiScaledWidth();
		int h = mc.getWindow().getGuiScaledHeight();

		// vignette: constant in Their World, swelling when Them are close, a faint hint as the Overworld sky goes wrong
		float vignette = ClientFractureState.progress() * 0.25F;
		if (TheirWorld.isIn(mc.level)) {
			vignette = 0.5F;
		}
		vignette = Math.max(vignette, ClientFractureState.proximity() * 0.95F);
		if (vignette > 0.01F) {
			RenderSystem.enableBlend();
			RenderSystem.defaultBlendFunc();
			graphics.setColor(1.0F, 1.0F, 1.0F, Mth.clamp(vignette, 0.0F, 1.0F));
			graphics.blit(VIGNETTE, 0, 0, w, h, 0.0F, 0.0F, 128, 128, 128, 128);
			graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
			RenderSystem.disableBlend();
		}

		float grip = ClientFractureState.gripAlpha(tickDelta);
		if (grip > 0.01F) {
			graphics.fill(0, 0, w, h, argb(grip, 0x7A0A16));
		}
		float flash = ClientFractureState.flashAlpha(tickDelta);
		if (flash > 0.01F) {
			graphics.fill(0, 0, w, h, argb(flash, 0xF2EEFF));
		}
		float black = ClientFractureState.blackAlpha(tickDelta);
		if (black > 0.005F) {
			graphics.fill(0, 0, w, h, argb(black, 0x000000));
		}
	}

	private static int argb(float alpha, int rgb) {
		return (RenderUtil.a255(alpha) << 24) | (rgb & 0xFFFFFF);
	}
}
