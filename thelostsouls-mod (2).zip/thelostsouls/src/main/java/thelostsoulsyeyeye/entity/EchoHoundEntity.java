package thelostsoulsyeyeye.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;
import net.minecraft.world.level.Level;
import thelostsoulsyeyeye.registry.ModSounds;

/** A dungeon guardian: the echo of something loyal. Fast, pack-spawned, glows cyan. Not one of Them. */
public class EchoHoundEntity extends CorruptedEntity {
	public EchoHoundEntity(EntityType<? extends EchoHoundEntity> type, Level level) {
		super(type, level);
		this.xpReward = 6;
	}

	public static AttributeSupplier.Builder createAttributes() {
		return createCorruptedAttributes(16.0D, 0.34D, 4.0D, 24.0D);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.goalSelector.addGoal(3, new LeapAtTargetGoal(this, 0.45F));
	}

	@Override
	protected double attackSpeedModifier() {
		return 1.25D;
	}

	@Override
	public boolean isThem() {
		return false;
	}

	@Override
	protected int rollFeatures(RandomSource random) {
		return 0;
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return ModSounds.ENTITY_ECHO_HOUND_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return ModSounds.ENTITY_ECHO_HOUND_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return ModSounds.ENTITY_ECHO_HOUND_DEATH;
	}

	@Override
	protected SoundEvent getAttackSound() {
		return ModSounds.ENTITY_ECHO_HOUND_ATTACK;
	}
}
