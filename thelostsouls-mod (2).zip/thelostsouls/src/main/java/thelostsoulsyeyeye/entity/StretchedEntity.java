package thelostsoulsyeyeye.entity;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import thelostsoulsyeyeye.registry.ModSounds;

/**
 * Too tall, too thin, and no face. It freezes solid while any player is looking at it, and covers
 * ground at a frightening speed the moment nobody is.
 */
public class StretchedEntity extends CorruptedEntity {
	private static final EntityDataAccessor<Boolean> DATA_OBSERVED =
			SynchedEntityData.defineId(StretchedEntity.class, EntityDataSerializers.BOOLEAN);
	private static final double HUNT_SPEED = 0.42D;

	public StretchedEntity(EntityType<? extends StretchedEntity> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return createCorruptedAttributes(40.0D, HUNT_SPEED, 9.0D, 64.0D);
	}

	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(DATA_OBSERVED, false);
	}

	public boolean isObserved() {
		return this.entityData.get(DATA_OBSERVED);
	}

	@Override
	public boolean isThem() {
		return true;
	}

	@Override
	protected int rollFeatures(RandomSource random) {
		int allowed = Deformity.MISSING_ARM_L | Deformity.MISSING_ARM_R | Deformity.EXTRA_ARM | Deformity.RIBS;
		return Deformity.roll(random, allowed, 0, 2);
	}

	@Override
	public void aiStep() {
		super.aiStep();
		if (this.level().isClientSide || this.tickCount % 2 != 0) {
			return;
		}
		boolean observed = false;
		for (Player player : this.level().players()) {
			if (!player.isSpectator() && player.isAlive() && this.distanceToSqr(player) < 4096.0D && isLookedAtBy(player)) {
				observed = true;
				break;
			}
		}
		if (observed != this.isObserved()) {
			this.entityData.set(DATA_OBSERVED, observed);
			AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
			if (speed != null) {
				speed.setBaseValue(observed ? 0.0D : HUNT_SPEED);
			}
		}
		if (observed) {
			this.getNavigation().stop();
		}
	}

	/** Same test an Enderman uses for "is the player staring at me", but with line of sight. */
	private boolean isLookedAtBy(Player player) {
		Vec3 look = player.getViewVector(1.0F).normalize();
		Vec3 toMe = new Vec3(this.getX() - player.getX(), this.getEyeY() - player.getEyeY(), this.getZ() - player.getZ());
		double dist = toMe.length();
		if (dist < 0.001D) {
			return true;
		}
		toMe = toMe.normalize();
		return look.dot(toMe) > 1.0D - 0.03D / dist && player.hasLineOfSight(this);
	}

	@Override
	public boolean doHurtTarget(Entity target) {
		// a watched Stretched cannot strike
		return !this.isObserved() && super.doHurtTarget(target);
	}

	@Override
	protected SoundEvent getStepSound() {
		return ModSounds.ENTITY_STRETCHED_STEP;
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return ModSounds.ENTITY_STRETCHED_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return ModSounds.ENTITY_STRETCHED_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return ModSounds.ENTITY_STRETCHED_DEATH;
	}

	@Override
	protected SoundEvent getAttackSound() {
		return ModSounds.ENTITY_STRETCHED_ATTACK;
	}
}
