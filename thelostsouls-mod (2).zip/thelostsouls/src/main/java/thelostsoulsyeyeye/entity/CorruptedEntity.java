package thelostsoulsyeyeye.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.AnimationState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Base class for everything that lives in Their World.
 *
 * "Them" ({@link #isThem()} == true) are the corrupted souls that hunt the player across the whole
 * dimension. The other kind (Echo Hounds, Remnants) are dungeon guardians: memories bound to the vaults.
 *
 * Every creature carries a synced bit-mask of {@link Deformity} flags, rolled once on its first tick.
 */
public abstract class CorruptedEntity extends Monster {
	private static final EntityDataAccessor<Integer> DATA_FEATURES =
			SynchedEntityData.defineId(CorruptedEntity.class, EntityDataSerializers.INT);

	/** Client-side animation states, driven in {@link #tick()} / {@link #handleEntityEvent(byte)}. */
	public final AnimationState idleAnimationState = new AnimationState();
	public final AnimationState attackAnimationState = new AnimationState();

	private boolean featuresRolled;

	protected CorruptedEntity(EntityType<? extends CorruptedEntity> type, Level level) {
		super(type, level);
		this.xpReward = 10;
	}

	public static AttributeSupplier.Builder createCorruptedAttributes(double health, double speed, double damage, double followRange) {
		return Monster.createMonsterAttributes()
				.add(Attributes.MAX_HEALTH, health)
				.add(Attributes.MOVEMENT_SPEED, speed)
				.add(Attributes.ATTACK_DAMAGE, damage)
				.add(Attributes.FOLLOW_RANGE, followRange)
				.add(Attributes.KNOCKBACK_RESISTANCE, 0.25D);
	}

	/** True for the hunters of Their World, false for dungeon guardians. */
	public abstract boolean isThem();

	protected abstract int rollFeatures(RandomSource random);

	protected abstract SoundEvent getAttackSound();

	protected double attackSpeedModifier() {
		return 1.15D;
	}

	// ------------------------------------------------------------------ synced deformities
	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(DATA_FEATURES, 0);
	}

	public int getFeatures() {
		return this.entityData.get(DATA_FEATURES);
	}

	public boolean hasFeature(int flag) {
		return (getFeatures() & flag) != 0;
	}

	@Override
	public void addAdditionalSaveData(CompoundTag tag) {
		super.addAdditionalSaveData(tag);
		tag.putInt("Features", getFeatures());
	}

	@Override
	public void readAdditionalSaveData(CompoundTag tag) {
		super.readAdditionalSaveData(tag);
		if (tag.contains("Features")) {
			this.entityData.set(DATA_FEATURES, tag.getInt("Features"));
			this.featuresRolled = true;
		}
	}

	// ------------------------------------------------------------------ behaviour
	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(2, new MeleeAttackGoal(this, attackSpeedModifier(), true));
		this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
		this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
		this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
		this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
		// mustSee = false: they always know where you are within their follow range. They think you are the threat.
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false, null));
	}

	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide) {
			this.idleAnimationState.startIfStopped(this.tickCount);
		} else if (!this.featuresRolled) {
			this.featuresRolled = true;
			this.entityData.set(DATA_FEATURES, rollFeatures(this.random));
		}
	}

	@Override
	public boolean doHurtTarget(Entity target) {
		this.level().broadcastEntityEvent(this, (byte) 4);
		this.playSound(getAttackSound(), 1.0F, 0.9F + this.random.nextFloat() * 0.2F);
		return super.doHurtTarget(target);
	}

	@Override
	public void handleEntityEvent(byte id) {
		if (id == 4) {
			this.attackAnimationState.start(this.tickCount);
		} else {
			super.handleEntityEvent(id);
		}
	}

	// ------------------------------------------------------------------ sound
	@Override
	public int getAmbientSoundInterval() {
		return 200;
	}

	protected SoundEvent getStepSound() {
		return SoundEvents.ZOMBIE_STEP;
	}

	@Override
	protected void playStepSound(BlockPos pos, BlockState state) {
		this.playSound(getStepSound(), 0.15F, 0.6F + this.random.nextFloat() * 0.2F);
	}
}
