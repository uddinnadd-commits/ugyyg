package thelostsoulsyeyeye.data;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Per-player persistent state, stored in the Overworld's data folder (data/thelostsouls_progress.dat):
 * how long they have spent under the Overworld sky, and how many times they have been pulled through.
 */
public class LostSoulsData extends SavedData {
	private static final String KEY = "thelostsouls_progress";

	private static final class Entry {
		long ticks;
		int cycles;
	}

	private final Map<UUID, Entry> players = new HashMap<>();

	public static LostSoulsData get(MinecraftServer server) {
		return server.overworld().getDataStorage().computeIfAbsent(LostSoulsData::load, LostSoulsData::new, KEY);
	}

	private Entry entry(UUID id) {
		return this.players.computeIfAbsent(id, k -> new Entry());
	}

	public long getTicks(UUID id) {
		return entry(id).ticks;
	}

	public long addTicks(UUID id, long delta) {
		Entry e = entry(id);
		e.ticks += delta;
		setDirty();
		return e.ticks;
	}

	public void setTicks(UUID id, long ticks) {
		entry(id).ticks = Math.max(0L, ticks);
		setDirty();
	}

	public int getCycles(UUID id) {
		return entry(id).cycles;
	}

	public void incrementCycles(UUID id) {
		entry(id).cycles++;
		setDirty();
	}

	public void reset(UUID id) {
		this.players.remove(id);
		setDirty();
	}

	@Override
	public CompoundTag save(CompoundTag tag) {
		ListTag list = new ListTag();
		for (Map.Entry<UUID, Entry> e : this.players.entrySet()) {
			CompoundTag c = new CompoundTag();
			c.putUUID("Id", e.getKey());
			c.putLong("Ticks", e.getValue().ticks);
			c.putInt("Cycles", e.getValue().cycles);
			list.add(c);
		}
		tag.put("Players", list);
		return tag;
	}

	public static LostSoulsData load(CompoundTag tag) {
		LostSoulsData data = new LostSoulsData();
		ListTag list = tag.getList("Players", Tag.TAG_COMPOUND);
		for (int i = 0; i < list.size(); i++) {
			CompoundTag c = list.getCompound(i);
			Entry e = new Entry();
			e.ticks = c.getLong("Ticks");
			e.cycles = c.getInt("Cycles");
			data.players.put(c.getUUID("Id"), e);
		}
		return data;
	}
}
