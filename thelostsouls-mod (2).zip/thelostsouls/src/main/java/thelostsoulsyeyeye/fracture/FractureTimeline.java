package thelostsoulsyeyeye.fracture;

/**
 * The scripted sequence, in ticks since the server sent FRACTURE_START (20 ticks = 1 second).
 * Shared by the server (effects, teleport) and the client (rendering, sound, camera) so they stay in lockstep.
 */
public final class FractureTimeline {
	private FractureTimeline() {}

	/** low rumble starts, sky darkens, a bright hairline appears */
	public static final int RUMBLE = 0;
	/** THE CRACK: flash, shards burst out of the sky */
	public static final int CRACK = 60;
	/** the tentacle begins to uncoil from the wound */
	public static final int SLITHER = 80;
	public static final int ROAR = 95;
	/** the camera is dragged up to look at it */
	public static final int LOOK_UP = 150;
	/** it has found you */
	public static final int PULL = 165;
	/** levitation begins: you are lifted into the sky */
	public static final int LEVITATE = 175;
	/** screen fades to black */
	public static final int FADE_START = 235;
	/** server moves the player to Their World */
	public static final int TELEPORT = 275;
}
