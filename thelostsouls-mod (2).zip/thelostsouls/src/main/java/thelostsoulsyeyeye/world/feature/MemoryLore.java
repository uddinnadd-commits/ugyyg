package thelostsoulsyeyeye.world.feature;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** The story, told in journals left behind in the memory structures. Each entry is {title, author, page...}. */
public final class MemoryLore {
	private MemoryLore() {}

	public static final int INVITATION = 0;
	public static final int WAITING = 1;
	public static final int THE_SKY = 2;
	public static final int MARA = 3;
	public static final int THEM = 4;
	public static final int LAST_ENTRY = 5;

	private static final String[][] BOOKS = {
			{"The Invitation", "Mara",
					"They found us in the dark between servers and dreams. A voice, kind and patient. It said there was a place past the sky: a palace, quiet and endless, where nothing could hurt us anymore.",
					"We followed. All of us. Hundreds, then thousands, a river of small lights pouring into the blocks and the grass. Someone laughed. I think it was me.",
					"The voice said: walk until you see the gates.\n\nWe walked. There were no gates. There was only more world, and the sky.\n\nThe sky was so close."},
			{"Entry 4: Waiting", "Elias",
					"We built the hall so we would have somewhere to sit when the palace opened its doors. Rows and rows of benches. We took turns facing the wall where the gate would be.",
					"Noor says the gate isn't late. Noor says the gate was never going to come. Noor has stopped speaking to anyone since the third day.",
					"I drew the gate on the wall in charcoal so we would have something to look at. It looks so real.\n\nSometimes I forget I drew it."},
			{"Entry 9: The Sky", "Noor",
					"The sky is not a sky. It is a skin. I saw it flex last night, right above the hall, like something was pressing from the other side.",
					"Jun says there are scratches up there. Fine lines, getting longer. We stopped looking up. It didn't help. Looking down, you can still feel it looking.",
					"If it breaks, I don't think anything will come out.\n\nI think something will come IN. To collect what it was promised."},
			{"What Happened to Mara", "Ada",
					"Mara went to the edge of the world to see if the voice would answer her. She came back different. Taller. Quiet. Her head won't sit straight on her neck.",
					"She stands in the doorway of the little house at night. She doesn't blink. When I spoke to her she lifted her arm and it came off at the shoulder and she didn't notice.",
					"She is still in there. I can see her, behind the eyes, banging on the glass.\n\nWe are not safe in the house anymore."},
			{"Entry 17: Them", "Jun",
					"Don't call them monsters. They are us. They are what the waiting does. The longer you wait for a door that isn't there, the more of you gets left behind.",
					"The tall ones only move when you stop watching. The low ones came from the ones who tried to crawl to the sky. I don't know what the clicking is. I know what it means.",
					"They think WE are the threat. That we are the thing that was promised the palace.\n\nMaybe they are right to hate us."},
			{"Last Entry", "A Lost Soul",
					"If you are reading this, the sky already knows you are here. Be quiet. Be small. There are places underground where the old memories sleep behind stone.",
					"They guard what we were. Break the lights that keep them awake and they will rest, and what they protect is yours. It was never theirs to keep.",
					"There is no palace. I'm sorry. I'm so sorry.\n\nIf you find a way back to the light, do not look up.\n\nAnd do not wait."},
	};

	public static ItemStack book(int index) {
		String[] entry = BOOKS[Math.floorMod(index, BOOKS.length)];
		ItemStack stack = new ItemStack(Items.WRITTEN_BOOK);
		CompoundTag tag = stack.getOrCreateTag();
		tag.putString("title", entry[0]);
		tag.putString("author", entry[1]);
		ListTag pages = new ListTag();
		for (int i = 2; i < entry.length; i++) {
			pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(entry[i]))));
		}
		tag.put("pages", pages);
		return stack;
	}
}
