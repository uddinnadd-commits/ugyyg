package thelostsoulsyeyeye.world.feature;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import thelostsoulsyeyeye.registry.ModBlocks;
import thelostsoulsyeyeye.registry.ModEntities;

/**
 * A Memory Vault: the dungeon. A ruined archway at the surface leads down a staircase into three chambers:
 *
 * <pre>
 *            (surface entrance)
 *                   |  stairs
 *   HALL  <-----  ANTECHAMBER  ----->  VAULT
 *  Remnants        Echo Hounds        Memory Cache
 * </pre>
 *
 * Both fighting chambers have monster spawners. Destroy the spawners and kill the guardians and the
 * Memory Cache in the vault will open (see MemoryCacheBlock).
 *
 * Local coordinates: +z runs away from the entrance, y = 0 is the surface. Everything stays within
 * x in [-15, 15], z in [0, 16] so the whole dungeon fits inside one generation window in any rotation.
 */
public class MemoryVaultFeature extends Feature<NoneFeatureConfiguration> {
	public MemoryVaultFeature() {
		super(NoneFeatureConfiguration.CODEC);
	}

	private static final int FLOOR = -10;     // floor blocks
	private static final int LOW = -9;        // lowest air block of a room
	private static final int HIGH = -5;       // highest air block of a room
	private static final int CEILING = -4;    // ceiling blocks

	private static void shell(StructureBuilder b, int x1, int z1, int x2, int z2) {
		for (int x = x1; x <= x2; x++) {
			for (int y = FLOOR; y <= CEILING; y++) {
				for (int z = z1; z <= z2; z++) {
					float r = b.random.nextFloat();
					b.set(x, y, z, r < 0.55F ? Blocks.POLISHED_BLACKSTONE_BRICKS : r < 0.8F ? Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS : Blocks.BLACKSTONE);
				}
			}
		}
	}

	@Override
	public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
		StructureBuilder b = new StructureBuilder(context.level(), context.origin(), context.random());
		int oy = b.origin.getY();
		if (!b.level.getBlockState(b.origin.below()).is(net.minecraft.tags.BlockTags.DIRT) || oy + FLOOR < b.level.getMinBuildHeight() + 3) {
			return false;
		}
		// the ground over the whole dungeon must not dip away from the ceiling
		int[][] samples = {{0, 0}, {-12, 12}, {12, 12}, {-12, 6}, {12, 6}, {0, 14}, {-8, 14}, {8, 14}, {0, 6}};
		for (int[] s : samples) {
			if (b.surfaceHeight(s[0], s[1]) < oy - 1) {
				return false;
			}
		}

		// 1. solid shells for the three chambers
		shell(b, -6, 9, 6, 16);      // antechamber
		shell(b, -15, 7, -7, 16);    // hall (west)
		shell(b, 7, 9, 15, 16);      // vault (east)
		// 2. hollow them out
		b.clear(-5, LOW, 10, 5, HIGH, 15);
		b.clear(-14, LOW, 8, -8, HIGH, 15);
		b.clear(8, LOW, 10, 14, HIGH, 15);
		// 3. doorways between the chambers
		b.clear(-7, LOW, 12, -6, LOW + 2, 14);
		b.clear(6, LOW, 12, 7, LOW + 2, 14);

		// 4. the staircase down from the surface (3 wide), cut into the hillside
		BlockState stairs = Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.NORTH).setValue(StairBlock.HALF, Half.BOTTOM);
		for (int k = 1; k <= 9; k++) {
			b.clear(-1, -k + 1, k, 1, -k + 3, k);
			for (int x = -1; x <= 1; x++) {
				b.set(x, -k, k, stairs);
			}
			for (int y = -k; y <= -k + 3; y++) {
				for (int sx : new int[]{-2, 2}) {
					if (!b.get(sx, y, k).isAir()) {
						b.set(sx, y, k, b.chance(0.7F) ? Blocks.POLISHED_BLACKSTONE_BRICKS : Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS);
					}
				}
			}
		}

		// 5. ruined archway on the surface: two broken pillars, one with a lantern that never went out
		int leftHeight = 3 + b.random.nextInt(2);
		for (int sx : new int[]{-3, 3}) {
			int h = sx < 0 ? leftHeight : 2 + b.random.nextInt(2);
			for (int y = -2; y <= h; y++) {
				b.set(sx, y, 0, y % 2 == 0 ? Blocks.CHISELED_POLISHED_BLACKSTONE : Blocks.POLISHED_BLACKSTONE_BRICKS);
			}
		}
		b.set(-3, leftHeight + 1, 0, Blocks.SOUL_LANTERN);
		b.wallSign(2, 1, 0, Direction.WEST, "BENEATH THE SKY", "WE KEPT THE", "MEMORIES SAFE", "");

		// 6. ANTECHAMBER: Echo Hounds
		for (int sx : new int[]{-3, 3}) {
			for (int z : new int[]{11, 14}) {
				for (int y = LOW; y <= HIGH; y++) {
					b.set(sx, y, z, y == LOW || y == HIGH ? Blocks.CHISELED_POLISHED_BLACKSTONE : Blocks.POLISHED_BLACKSTONE_BRICKS);
				}
			}
		}
		b.spawner(-4, LOW, 12, ModEntities.ECHO_HOUND);
		b.spawner(4, LOW, 12, ModEntities.ECHO_HOUND);
		furnish(b, -5, 10, 5, 15);

		// 7. HALL: Remnants and a wall of ruined shelves
		b.spawner(-13, LOW, 9, ModEntities.REMNANT);
		b.spawner(-13, LOW, 14, ModEntities.REMNANT);
		for (int x = -14; x <= -8; x++) {
			for (int y = LOW; y <= LOW + 1; y++) {
				if (b.chance(0.55F)) {
					b.set(x, y, 8, Blocks.BOOKSHELF);
				}
			}
		}
		for (int z : new int[]{10, 13}) {
			for (int y = LOW; y <= HIGH; y++) {
				b.set(-11, y, z, Blocks.POLISHED_BLACKSTONE_BRICKS);
			}
		}
		b.lectern(-9, LOW, 12, Direction.EAST, MemoryLore.book(MemoryLore.INVITATION));
		furnish(b, -14, 8, -8, 15);

		// 8. VAULT: the Memory Cache
		b.set(11, LOW, 12, ModBlocks.MEMORY_CACHE);
		for (int sx : new int[]{10, 12}) {
			for (int sz : new int[]{11, 13}) {
				b.set(sx, LOW, sz, Blocks.CRYING_OBSIDIAN);
			}
		}
		b.set(11, LOW - 1, 12, Blocks.GILDED_BLACKSTONE);
		b.lectern(14, LOW, 12, Direction.WEST, MemoryLore.book(MemoryLore.LAST_ENTRY));
		BlockState lantern = Blocks.SOUL_LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
		b.set(9, HIGH, 11, lantern);
		b.set(9, HIGH, 14, lantern);
		b.set(13, HIGH, 11, lantern);
		b.set(13, HIGH, 14, lantern);
		return true;
	}

	/** Dressing: hanging soul lanterns, cobwebs, bones and old stains. */
	private static void furnish(StructureBuilder b, int x1, int z1, int x2, int z2) {
		BlockState lantern = Blocks.SOUL_LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
		int cx = (x1 + x2) / 2;
		int cz = (z1 + z2) / 2;
		b.set(cx, HIGH, cz, lantern);
		for (int i = 0; i < 10; i++) {
			int x = x1 + b.random.nextInt(x2 - x1 + 1);
			int z = z1 + b.random.nextInt(z2 - z1 + 1);
			Block block = i < 4 ? Blocks.COBWEB : i < 6 ? Blocks.SKELETON_SKULL : i < 8 ? Blocks.BONE_BLOCK : Blocks.RED_CARPET;
			int y = i < 4 ? HIGH : LOW;
			if (b.get(x, y, z).isAir()) {
				b.set(x, y, z, block);
			}
		}
	}
}
