package thelostsoulsyeyeye.world.feature;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** A bare, twisted tree: a leaning dark-oak trunk, crooked branches, and fence-post twigs at the tips. No leaves. */
public class DeadTreeFeature extends Feature<NoneFeatureConfiguration> {
	public DeadTreeFeature() {
		super(NoneFeatureConfiguration.CODEC);
	}

	private static boolean canReplace(WorldGenLevel level, BlockPos pos) {
		BlockState state = level.getBlockState(pos);
		return state.isAir() || state.canBeReplaced();
	}

	private static BlockState log(Direction.Axis axis) {
		return Blocks.DARK_OAK_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, axis);
	}

	@Override
	public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
		WorldGenLevel level = context.level();
		BlockPos origin = context.origin();
		RandomSource random = context.random();
		if (!level.getBlockState(origin.below()).is(BlockTags.DIRT) || !canReplace(level, origin)) {
			return false;
		}
		int height = 5 + random.nextInt(8);
		int x = origin.getX();
		int z = origin.getZ();
		BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
		for (int i = 0; i < height; i++) {
			int y = origin.getY() + i;
			p.set(x, y, z);
			if (!canReplace(level, p)) {
				if (i < 3) {
					return false;
				}
				break;
			}
			level.setBlock(p, log(Direction.Axis.Y), 2);
			if (i >= 3 && random.nextInt(3) == 0) {
				branch(level, random, x, y, z);
			}
			if (i > 1 && random.nextInt(4) == 0) {
				// the trunk kinks sideways, joined face-to-face so it stays one piece
				Direction d = Direction.Plane.HORIZONTAL.getRandomDirection(random);
				x += d.getStepX();
				z += d.getStepZ();
				p.set(x, y, z);
				if (canReplace(level, p)) {
					level.setBlock(p, log(d.getAxis()), 2);
				}
			}
		}
		// the tip of the trunk splinters
		p.set(x, origin.getY() + height, z);
		if (canReplace(level, p)) {
			level.setBlock(p, Blocks.DARK_OAK_FENCE.defaultBlockState(), 2);
		}
		return true;
	}

	private static void branch(WorldGenLevel level, RandomSource random, int sx, int sy, int sz) {
		Direction d = Direction.Plane.HORIZONTAL.getRandomDirection(random);
		int length = 2 + random.nextInt(4);
		int x = sx;
		int y = sy;
		int z = sz;
		BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
		for (int i = 0; i < length; i++) {
			x += d.getStepX();
			z += d.getStepZ();
			if (i % 2 == 1) {
				y++;
			}
			if (random.nextInt(4) == 0) {
				Direction side = random.nextBoolean() ? d.getClockWise() : d.getCounterClockWise();
				x += side.getStepX();
				z += side.getStepZ();
			}
			p.set(x, y, z);
			if (!canReplace(level, p)) {
				return;
			}
			boolean tip = i == length - 1;
			level.setBlock(p, tip ? Blocks.DARK_OAK_FENCE.defaultBlockState() : log(d.getAxis()), 2);
			if (tip) {
				p.set(x, y + 1, z);
				if (canReplace(level, p)) {
					level.setBlock(p, Blocks.DARK_OAK_FENCE.defaultBlockState(), 2);
				}
			}
		}
	}
}
