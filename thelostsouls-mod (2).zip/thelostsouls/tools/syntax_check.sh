#!/bin/sh
# Parse-only sanity check. javac cannot resolve Minecraft classes without the game jars, so almost every
# line it prints is "cannot find symbol"-style noise. A file that fails to PARSE is reported with one of the
# messages below, and when any file fails to parse javac stops before the noisy phase, so this is reliable.
cd "$(dirname "$0")/.."
OUT=$(mktemp -d)
javac -proc:none -Xmaxerrs 100000 -d "$OUT" $(find src -name '*.java') > /tmp/javac_all.txt 2>&1
grep -E "error: (.*expected|illegal start|unclosed|not a statement|reached end of file|class, interface|invalid method declaration|orphaned|illegal character|malformed|unterminated|else without if|missing return statement|variable .* is already defined|duplicate class|incompatible types: .*lossy|unreachable statement|array required)" /tmp/javac_all.txt > /tmp/real_errors.txt
echo "files: $(find src -name '*.java' | wc -l)   syntax-class errors: $(wc -l < /tmp/real_errors.txt)   total javac lines (mostly unresolved-symbol noise): $(grep -c 'error:' /tmp/javac_all.txt)"
head -40 /tmp/real_errors.txt
rm -rf "$OUT"
