"""
Shared helpers for the asset generators.

Everything the mod needs that is not hand-written Java/JSON (textures, sounds,
model skeletons, sounds.json, ModSounds.java) is produced by the scripts in this
folder.  Run `python3 tools/build_assets.py` from the project root to regenerate.
Requires: numpy, scipy, Pillow, ffmpeg (with libvorbis) on PATH.
"""
import os
import math
import random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

MOD_ID = "thelostsouls"
PKG = "thelostsoulsyeyeye"

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RES = os.path.join(ROOT, "src", "main", "resources")
ASSETS = os.path.join(RES, "assets", MOD_ID)
DATA = os.path.join(RES, "data", MOD_ID)
JAVA_MAIN = os.path.join(ROOT, "src", "main", "java", PKG)
JAVA_CLIENT = os.path.join(ROOT, "src", "client", "java", PKG, "client")


def ensure(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


def write_text(path, text):
    ensure(path)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def clamp8(a):
    return np.clip(a, 0, 255).astype(np.uint8)


def value_noise(h, w, cell, rng):
    """Smooth low-frequency noise in 0..1, shape (h, w)."""
    gh, gw = max(2, h // cell + 2), max(2, w // cell + 2)
    grid = rng.random((gh, gw)).astype(np.float32)
    im = Image.fromarray((grid * 255).astype(np.uint8)).resize((w, h), Image.BICUBIC)
    return np.asarray(im, dtype=np.float32) / 255.0


def fbm(h, w, rng, base_cell=32, octaves=4):
    out = np.zeros((h, w), dtype=np.float32)
    amp, total = 1.0, 0.0
    cell = base_cell
    for _ in range(octaves):
        out += value_noise(h, w, max(1, int(cell)), rng) * amp
        total += amp
        amp *= 0.5
        cell /= 2
    return out / total


def new_rgba(w, h, color=(0, 0, 0, 0)):
    return Image.new("RGBA", (w, h), color)


def save_png(img, relpath):
    path = ensure(os.path.join(ASSETS, "textures", relpath))
    img.save(path)
    return path
