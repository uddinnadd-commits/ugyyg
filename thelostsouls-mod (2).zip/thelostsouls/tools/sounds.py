"""
Procedural sound design. Every sound is synthesised with numpy (no samples, no licences),
written as mono 44.1 kHz WAV and encoded to Ogg Vorbis with ffmpeg.

Also emits:  assets/thelostsouls/sounds.json,  ModSounds.java,  subtitles.json (merged into en_us.json)
"""
import json
import subprocess
import tempfile
import wave
from scipy import signal
from common import *

SR = 44100
rng = np.random.default_rng(2024)
TAU = 2 * math.pi


# ------------------------------------------------------------------------------------- DSP
def tt(d):
    return np.arange(int(d * SR), dtype=np.float64) / SR


def noise(d):
    return rng.uniform(-1, 1, int(d * SR))


def _sos(kind, f, order=2):
    nyq = SR / 2
    if kind == "band":
        lo, hi = max(f[0], 20.0), min(f[1], nyq - 200)
        if lo >= hi:
            return None
        return signal.butter(order, [lo / nyq, hi / nyq], btype="band", output="sos")
    f = min(max(f, 20.0), nyq - 200)
    return signal.butter(order, f / nyq, btype=kind, output="sos")


def bp(x, lo, hi, order=2):
    s = _sos("band", (lo, hi), order)
    return x * 0 if s is None else signal.sosfilt(s, x)


def lp(x, f, order=2):
    return signal.sosfilt(_sos("low", f, order), x)


def hp(x, f, order=2):
    return signal.sosfilt(_sos("high", f, order), x)


def expd(n_or_d, tau):
    d = n_or_d if isinstance(n_or_d, float) else n_or_d / SR
    return np.exp(-tt(d) / tau)


def attack(x, a):
    n = min(len(x), int(a * SR))
    if n > 0:
        x = x.copy()
        x[:n] *= np.linspace(0, 1, n) ** 1.5
    return x


def fade_out(x, f=0.05):
    n = min(len(x), int(f * SR))
    if n > 0:
        x = x.copy()
        x[-n:] *= np.linspace(1, 0, n)
    return x


def norm(x, peak=0.85):
    m = np.max(np.abs(x))
    return x if m < 1e-9 else x / m * peak


def place(total, parts):
    """parts: list of (array, start_seconds, gain)"""
    out = np.zeros(int(total * SR))
    for arr, st, g in parts:
        s = int(st * SR)
        e = min(len(out), s + len(arr))
        if e > s:
            out[s:e] += arr[: e - s] * g
    return out


def reverb(x, rt=1.2, wet=0.3, tone=3500):
    n = int(rt * SR)
    ir = lp(rng.normal(0, 1, n), tone) * np.exp(-np.arange(n) / SR / (rt / 4.0))
    wetsig = signal.fftconvolve(x, ir)[: len(x) + n // 2]
    wetsig = norm(wetsig, np.max(np.abs(x)) + 1e-9)
    out = np.zeros(len(wetsig))
    out[: len(x)] += x * (1 - wet)
    out += wetsig * wet
    return out


def smooth_noise(d, rate):
    """slowly varying noise 0..1"""
    n = int(d * SR)
    k = max(2, int(d * rate) + 2)
    pts = rng.random(k)
    return np.interp(np.linspace(0, k - 1, n), np.arange(k), pts)


def voice(d, f0a, f0b, formants, breath=0.15, vib=(5.5, 0.012), rough=0.0, buzz=1.0, f0_curve=None):
    """Crude source-filter vocal tract: buzzy glottal source through resonant formants."""
    n = int(d * SR)
    t = tt(d)
    f0 = np.linspace(f0a, f0b, n) if f0_curve is None else f0_curve
    f0 = f0 * (1 + vib[1] * np.sin(TAU * vib[0] * t))
    if rough > 0:
        f0 = f0 * (1 + rough * (smooth_noise(d, 28) - 0.5))
    phase = np.cumsum(f0) / SR
    src = (2 * (phase % 1.0) - 1) * buzz
    src = src - np.concatenate([[0], src[:-1]]) * 0.5
    out = np.zeros(n)
    for (f, bw, g) in formants:
        out += bp(src, f - bw / 2, f + bw / 2) * g * 3.0
        out += bp(noise(d), f - bw, f + bw) * g * breath
    return out


def tinkle(f, tau, d=0.5):
    t = tt(d)
    return (np.sin(TAU * f * t) + 0.45 * np.sin(TAU * f * 2.76 * t) * np.exp(-t / (tau * 0.5))) * np.exp(-t / tau)


def thump(f0, f1, tau, d=0.5):
    t = tt(d)
    f = f1 + (f0 - f1) * np.exp(-t / 0.05)
    ph = np.cumsum(f) / SR
    return np.sin(TAU * ph) * np.exp(-t / tau) * (1 - np.exp(-t / 0.003))


def shatter(d, count=80, lo=2200, hi=9500, tau_scale=1.0, spread=None):
    out = np.zeros(int(d * SR))
    spread = spread or d / 3.5
    for _ in range(count):
        st = min(d - 0.45, rng.exponential(spread))
        f = rng.uniform(lo, hi)
        tau = rng.uniform(0.02, 0.16) * tau_scale
        g = rng.uniform(0.15, 1.0) * np.exp(-st / (d / 2))
        tk = tinkle(f, tau, 0.4) + hp(noise(0.4), 4000) * np.exp(-tt(0.4) / 0.004) * 0.6
        s = int(st * SR)
        out[s: s + len(tk)] += tk[: len(out) - s] * g
    return out


# ------------------------------------------------------------------------------ recipes
def walker_ambient(f0a, f0b, seed_shift=0.0, d=1.8):
    n = int(d * SR)
    t = tt(d)
    v = voice(d, f0a, f0b, [(450 + seed_shift * 60, 110, 1.0), (1100 + seed_shift * 150, 160, 0.7), (2300, 300, 0.35)],
              breath=0.45, rough=0.5)
    am = 0.35 + 0.65 * (0.5 + 0.5 * np.sin(TAU * 3.1 * t + 1.0)) ** 1.5
    env = np.sin(np.pi * np.linspace(0, 1, n)) ** 0.7
    return norm(lp(v * am * env, 3800), 0.8)


def walker_hurt(f_shift=1.0):
    v = voice(0.55, 170 * f_shift, 260 * f_shift, [(700, 140, 1.0), (1500, 200, 0.8), (2600, 300, 0.4)], breath=0.5, rough=0.6)
    v = np.tanh(v * 2.0) * expd(0.55, 0.28)
    return norm(attack(v, 0.01), 0.85)


def walker_death():
    d = 2.0
    t = tt(d)
    v = voice(d, 140, 38, [(420, 100, 1.0), (900, 150, 0.8), (1800, 250, 0.4)], breath=0.5, rough=0.8)
    gurgle = 0.5 + 0.5 * np.sin(TAU * 9 * t + 2 * np.sin(TAU * 1.5 * t))
    v = v * (0.4 + 0.6 * gurgle) * expd(d, 0.9)
    v += bp(noise(d), 300, 1400) * expd(d, 0.5) * 0.25 * gurgle
    return norm(fade_out(attack(v, 0.02), 0.3), 0.85)


def walker_attack():
    d = 0.65
    v = voice(d, 100, 170, [(600, 140, 1.0), (1300, 200, 0.8), (2400, 300, 0.5)], breath=0.8, rough=0.7)
    v = np.tanh(v * 3.0) * np.sin(np.pi * np.linspace(0, 1, int(d * SR))) ** 0.5
    return norm(v, 0.85)


def crawler_ambient(seed_len=1.6):
    d = seed_len
    n = int(d * SR)
    clicks = np.zeros(n)
    t = 0.05
    while t < d - 0.1:
        s = int(t * SR)
        burst = bp(noise(0.012), 1800, 5200) * np.exp(-tt(0.012) / 0.002) * rng.uniform(0.4, 1.0)
        clicks[s: s + len(burst)] += burst[: n - s]
        t += rng.uniform(0.03, 0.16) if rng.random() < 0.75 else rng.uniform(0.2, 0.4)
    rattle = bp(noise(d), 150, 900) * (smooth_noise(d, 12) ** 3) * 0.5
    return norm(clicks * 1.4 + rattle, 0.75)


def crawler_screech(d, a, b, rough=0.5):
    v = voice(d, a, b, [(900, 180, 1.0), (2600, 320, 0.9), (4200, 500, 0.4)], breath=0.5, rough=rough)
    v = np.tanh(v * 2.2) * np.sin(np.pi * np.linspace(0, 1, int(d * SR))) ** 0.4
    return norm(v, 0.85)


def crawler_death():
    d = 1.4
    t = tt(d)
    g = 0.5 + 0.5 * np.sin(TAU * 14 * t)
    v = bp(noise(d), 200, 1800) * g * expd(d, 0.5) + voice(d, 520, 140, [(900, 200, 1.0), (2000, 300, 0.5)], breath=0.4, rough=0.7) * expd(d, 0.45) * 0.6
    return norm(fade_out(v, 0.2), 0.8)


def stretched_ambient(variant=0):
    d = 3.2
    t = tt(d)
    f = 46 + 5 * variant
    v = voice(d, f, f * 0.9, [(250, 60, 1.0), (700, 100, 0.7), (1600, 200, 0.3)], breath=0.3, vib=(0.6, 0.02), rough=0.2)
    tremolo = 0.6 + 0.4 * np.sin(TAU * (0.45 + 0.1 * variant) * t)
    wh = np.zeros(int(d * SR))
    for k in range(5 + variant):
        st = rng.uniform(0.2, d - 1.0)
        dur = rng.uniform(0.25, 0.6)
        seg = bp(noise(dur), rng.uniform(1200, 2400), rng.uniform(3000, 5200)) * np.sin(np.pi * np.linspace(0, 1, int(dur * SR))) ** 2
        s = int(st * SR)
        wh[s: s + len(seg)] += seg[: len(wh) - s] * 0.35
    env = np.sin(np.pi * np.linspace(0, 1, int(d * SR))) ** 0.6
    return norm(reverb((lp(v, 2500) * tremolo + wh) * env, 1.2, 0.3), 0.8)


def stretched_hurt():
    d = 1.0
    v = voice(d, 130, 52, [(300, 70, 1.0), (900, 120, 0.9), (1900, 250, 0.5)], breath=0.4, rough=0.9, vib=(7, 0.03))
    v = np.tanh(v * 2) * expd(d, 0.45)
    creak = bp(noise(d), 600, 2000) * (smooth_noise(d, 30) ** 2) * 0.4
    return norm(attack(v + creak, 0.02), 0.85)


def stretched_death():
    d = 3.5
    t = tt(d)
    v = voice(d, 110, 34, [(300, 80, 1.0), (800, 140, 0.8), (1700, 250, 0.4)], breath=0.6, rough=0.5)
    breath_ = bp(noise(d), 400, 1900) * np.sin(np.pi * np.linspace(0, 1, int(d * SR))) ** 0.8 * 0.6
    return norm(reverb(fade_out((v * expd(d, 1.3) + breath_) * (0.7 + 0.3 * np.sin(TAU * 5 * t)), 0.5), 1.4, 0.3), 0.85)


def stretched_step(variant):
    d = 0.32
    click = bp(noise(d), 900, 3200) * np.exp(-tt(d) / 0.012)
    click2 = bp(noise(d), 1200, 4200) * np.exp(-tt(d) / 0.01)
    th = thump(90, 55, 0.07, d) * 0.9
    out = place(d, [(click, 0.0, 1.0), (click2, 0.07 + 0.02 * variant, 0.6), (th, 0.0, 0.8)])
    return norm(out, 0.7)


def hound_growl(d, f):
    n = int(d * SR)
    t = tt(d)
    saw = signal.sawtooth(TAU * np.cumsum(np.full(n, f) * (1 + 0.04 * np.sin(TAU * 3 * t))) / SR)
    am = 0.5 + 0.5 * np.sin(TAU * 27 * t)
    body = bp(saw, 150, 900) * (0.5 + 0.5 * am) + bp(noise(d), 300, 1500) * 0.35 * am
    env = np.sin(np.pi * np.linspace(0, 1, n)) ** 0.6
    return norm(reverb(body * env, 0.8, 0.2), 0.8)


def hound_yelp():
    d = 0.5
    n = int(d * SR)
    f = 480 + 520 * np.sin(np.pi * np.linspace(0, 1, n)) ** 0.7
    v = voice(d, 0, 0, [(900, 200, 1.0), (2200, 300, 0.7)], breath=0.3, rough=0.2, f0_curve=f)
    return norm(attack(v, 0.01) * expd(d, 0.3), 0.85)


def hound_death():
    d = 1.6
    t = tt(d)
    f = np.linspace(760, 170, int(d * SR))
    v = voice(d, 0, 0, [(800, 180, 1.0), (2000, 300, 0.6)], breath=0.4, vib=(6, 0.05), rough=0.3, f0_curve=f)
    return norm(fade_out(reverb(v * expd(d, 0.8) * (0.7 + 0.3 * np.sin(TAU * 8 * t)), 1.0, 0.25), 0.3), 0.85)


def hound_bark():
    d = 0.4
    v = voice(d, 220, 150, [(600, 150, 1.0), (1400, 250, 0.8), (2600, 400, 0.4)], breath=0.7, rough=0.4)
    v = np.tanh(v * 3) * expd(d, 0.12)
    return norm(attack(v, 0.004), 0.9)


def remnant_ring(f, d=1.8, whisper=True):
    t = tt(d)
    x = sum(a * np.sin(TAU * f * r * t) * np.exp(-t / (1.1 / r)) for r, a in ((1, 1.0), (2.76, 0.6), (5.4, 0.35), (8.93, 0.2)))
    x = x * (0.5 + 0.5 * np.sin(TAU * 5 * t + 1)) ** 0.5
    if whisper:
        x = x * 0.7 + bp(noise(d), 1500, 4000) * (smooth_noise(d, 8) ** 3) * 0.35
    return norm(reverb(attack(x, 0.04), 1.4, 0.35), 0.75)


def clank(d=0.45):
    t = tt(d)
    hit = bp(noise(d), 800, 7000) * np.exp(-t / 0.02)
    ring = sum(a * np.sin(TAU * f * t) * np.exp(-t / tau) for f, a, tau in ((420, 1, 0.12), (1160, 0.7, 0.08), (2270, 0.5, 0.05), (3700, 0.3, 0.03)))
    return norm(hit * 0.8 + ring, 0.85)


def remnant_death():
    d = 2.0
    parts = [(clank(0.5), 0.0, 1.0), (clank(0.4), 0.22, 0.7), (clank(0.4), 0.43, 0.6), (clank(0.35), 0.72, 0.45), (clank(0.3), 1.0, 0.3)]
    low = voice(d, 90, 36, [(300, 80, 1.0), (800, 150, 0.5)], breath=0.5) * expd(d, 0.5) * 0.5
    return norm(reverb(place(d, parts) + low, 1.2, 0.3), 0.85)


# ---------------------------------------------------------------------------- fracture set
def sky_rumble():
    d = 7.0
    t = tt(d)
    n = int(d * SR)
    swell = (np.linspace(0, 1, n) ** 1.6)
    low = lp(noise(d), 90, 3) * 3.0
    sub = np.sin(TAU * (28 + 10 * swell) * t) * 0.6
    crackle = np.zeros(n)
    for _ in range(int(40 * d)):
        st = rng.random() ** 2.0 * (d - 0.2)
        s = int(st * SR)
        tk = bp(noise(0.1), 900, 5000) * np.exp(-tt(0.1) / 0.012) * rng.uniform(0.2, 1.0) * (0.3 + st / d)
        crackle[s: s + len(tk)] += tk[: n - s]
    x = (low + sub) * (0.15 + 0.85 * swell) + crackle * 0.5 * swell
    return norm(fade_out(x, 0.3), 0.9)


def sky_crack():
    d = 4.0
    t = tt(d)
    n = int(d * SR)
    snap = noise(d) * np.exp(-t / 0.01)
    boom = np.sin(TAU * np.cumsum(34 + 90 * np.exp(-t / 0.15)) / SR) * np.exp(-t / 1.1)
    tear = bp(noise(d), 500, 6500) * np.exp(-t / 0.55) * (0.5 + 0.5 * smooth_noise(d, 40))
    clicks = np.zeros(n)
    for _ in range(260):
        st = rng.exponential(0.7)
        if st > d - 0.1:
            continue
        s = int(st * SR)
        tk = bp(noise(0.06), 1500, 9000) * np.exp(-tt(0.06) / 0.006) * rng.uniform(0.2, 1.0) * np.exp(-st / 1.0)
        clicks[s: s + len(tk)] += tk[: n - s]
    x = snap * 1.0 + boom * 1.3 + tear * 0.7 + clicks * 0.9 + shatter(d, 40, 2600, 9000, 0.8, 0.5) * 0.35
    x = np.tanh(x * 1.1)
    return norm(reverb(fade_out(x, 0.4), 2.2, 0.28), 0.72)


def glass_shatter():
    d = 4.0
    x = shatter(d, 140, 2000, 10500, 1.2, 0.9)
    x += hp(noise(d), 5000) * np.exp(-tt(d) / 0.3) * 0.25
    return norm(reverb(fade_out(x, 0.5), 1.6, 0.3), 0.85)


def tentacle_roar():
    d = 5.0
    t = tt(d)
    n = int(d * SR)
    swell = np.sin(np.pi * np.linspace(0, 1, n) ** 0.7) ** 1.2
    f = 54 + 14 * np.sin(TAU * 0.6 * t) + 22 * swell
    mod = np.sin(TAU * np.cumsum(f * 0.5) / SR) * (1.5 + 4.0 * swell)
    car = np.sin(TAU * np.cumsum(f) / SR + mod)
    growl = voice(d, 78, 52, [(260, 70, 1.0), (620, 110, 0.9), (1300, 200, 0.5)], breath=0.6, rough=0.9)
    rumble = lp(noise(d), 160, 3) * 2.0
    x = (car * 0.9 + growl * 0.8 + rumble) * swell
    x = np.tanh(x * 1.6)
    return norm(reverb(x, 2.0, 0.3), 0.92)


def tentacle_slither():
    d = 2.8
    t = tt(d)
    gate = (0.5 + 0.5 * np.sin(TAU * 6.2 * t + 3 * np.sin(TAU * 0.9 * t))) ** 3
    wet = bp(noise(d), 180, 1500) * gate
    squelch = lp(noise(d), 600) * (smooth_noise(d, 14) ** 2) * 2.0
    x = (wet * 1.0 + squelch * 0.6) * np.sin(np.pi * np.linspace(0, 1, int(d * SR))) ** 0.5
    return norm(x, 0.8)


def pull_whoosh():
    d = 4.0
    t = tt(d)
    n = int(d * SR)
    rise = np.linspace(0, 1, n)
    f = 110 * (1 + 3.2 * rise ** 1.3)
    ph = np.cumsum(f) / SR
    choir = sum(np.sin(TAU * ph * r + k) / (1 + 0.3 * k) for k, r in enumerate((1, 1.5, 2.0, 3.0, 4.0)))
    choir *= 1 + 0.15 * np.sin(TAU * 5.5 * t)
    air = hp(noise(d), 800) * rise ** 2
    x = (choir * 0.5 + air * 1.1) * (0.1 + 0.9 * rise ** 1.2)
    x = np.tanh(x * 1.3)
    return norm(fade_out(reverb(x, 1.5, 0.25), 0.25), 0.6)


def arrive_boom():
    pre = 1.3
    tail_d = 3.0
    hit = noise(0.5) * np.exp(-tt(0.5) / 0.03) * 0.8
    boom = thump(70, 32, 0.9, tail_d)
    full = place(tail_d, [(boom, 0.0, 1.0), (hit, 0.0, 0.6)])
    tail = reverb(full, 2.4, 0.55, 2000)
    swell = (bp(noise(pre), 80, 1200) * np.linspace(0, 1, int(pre * SR)) ** 3) * 0.5
    return norm(np.concatenate([swell, tail]), 0.95)


def sky_creak(seed):
    d = 1.6 + 0.3 * seed
    t = tt(d)
    f = 620 + 90 * seed + 70 * np.sin(TAU * 1.3 * t) + 35 * np.sin(TAU * 7.1 * t)
    ph = np.cumsum(f) / SR
    x = sum(np.sin(TAU * ph * k) / k ** 1.3 for k in range(1, 5))
    x *= 0.3 + 0.7 * smooth_noise(d, 9)
    x = attack(x, 0.2) * np.sin(np.pi * np.linspace(0, 1, int(d * SR))) ** 0.8
    sub = np.sin(TAU * 41 * t) * 0.15
    return norm(reverb(lp(x, 4200) + sub, 1.6, 0.3), 0.7)


def whisper(seed, far=False):
    d = 3.2
    n = int(d * SR)
    out = np.zeros(n)
    t0 = 0.1
    while t0 < d - 0.4:
        dur = rng.uniform(0.12, 0.32)
        c = rng.uniform(1400, 4200)
        seg = bp(noise(dur), c * 0.7, c * 1.3) * np.sin(np.pi * np.linspace(0, 1, int(dur * SR))) ** 2
        v = voice(dur, 150 + 20 * seed, 130 + 20 * seed, [(500, 120, 1.0), (1500, 200, 0.6)], breath=0.5, rough=0.3) * 0.25
        v *= np.sin(np.pi * np.linspace(0, 1, len(v))) ** 2
        s = int(t0 * SR)
        out[s: s + len(seg)] += (seg + v[: len(seg)])[: n - s]
        t0 += rng.uniform(0.2, 0.45)
    out = reverb(out, 1.8, 0.45)
    if far:
        out = lp(out, 2400) * 0.8
    return norm(out, 0.55 if far else 0.65)


def distant_scream():
    d = 3.0
    n = int(d * SR)
    r = np.linspace(0, 1, n)
    f = 360 + 400 * np.sin(np.pi * r) ** 1.5 - 120 * r
    v = voice(d, 0, 0, [(800, 120, 1.0), (1500, 150, 0.9), (3000, 300, 0.5)], breath=0.4, rough=0.5, vib=(6.5, 0.03), f0_curve=f)
    v = np.tanh(v * 2.0) * np.sin(np.pi * r) ** 1.2
    return norm(reverb(lp(v, 3600), 2.4, 0.65), 0.6)


def their_world_loop():
    L = 16.0
    n = int(L * SR)
    t = np.arange(n) / SR
    x = np.zeros(n)
    partials = [(55.0, 0.8, 1), (55.5625, 0.6, 2), (82.5, 0.4, 3), (110.25, 0.3, 1), (164.5, 0.16, 2), (247.125, 0.08, 5)]
    for k, (f, a, lfo) in enumerate(partials):
        x += a * np.sin(TAU * f * t + k) * (0.65 + 0.35 * np.sin(TAU * lfo / L * t + k * 1.7))
    spec = np.zeros(n // 2 + 1, dtype=np.complex128)
    bins = np.arange(1, min(len(spec), int(500 * L)))
    mag = 1.0 / np.sqrt(bins)
    spec[bins] = mag * np.exp(1j * rng.uniform(0, TAU, len(bins)))
    bed = np.fft.irfft(spec, n)
    bed = bed / np.max(np.abs(bed)) * 0.6
    swell = 0.5 + 0.5 * np.sin(TAU * 2 / L * t)
    x = x * 0.45 + bed * (0.35 + 0.65 * swell)
    return norm(x, 0.55)


def heartbeat():
    d = 0.9
    lub = thump(75, 42, 0.07, d)
    dub = thump(65, 38, 0.06, d)
    x = place(d, [(lub, 0.0, 1.0), (dub, 0.21, 0.7)])
    return norm(lp(x, 220), 0.95)


def cache_open():
    d = 3.0
    parts = []
    for i, f in enumerate((392, 523, 659, 784, 1047, 1319)):
        parts.append((tinkle(f, 0.9, 1.6) * 0.8, 0.12 * i, 1.0 / (1 + 0.15 * i)))
    return norm(reverb(place(d, parts), 2.2, 0.45), 0.8)


def cache_deny():
    d = 0.7
    x = place(d, [(thump(110, 55, 0.12, d), 0.0, 1.0),
                  (np.sin(TAU * 220 * tt(d)) * np.exp(-tt(d) / 0.18) * 0.4, 0.0, 1.0),
                  (np.sin(TAU * 233 * tt(d)) * np.exp(-tt(d) / 0.18) * 0.4, 0.0, 1.0)])
    return norm(x, 0.8)


# --------------------------------------------------------------------------- event table
EVENTS = [
    # (event id, subtitle, [(file path, generator)])
    ("entity.hollow_walker.ambient", "Hollow Walker groans",
     [("entity/hollow_walker/ambient1", lambda: walker_ambient(88, 62, 0.0)),
      ("entity/hollow_walker/ambient2", lambda: walker_ambient(72, 55, 0.6, 2.2)),
      ("entity/hollow_walker/ambient3", lambda: walker_ambient(105, 70, -0.5, 1.5))]),
    ("entity.hollow_walker.hurt", "Hollow Walker shrieks",
     [("entity/hollow_walker/hurt1", lambda: walker_hurt(1.0)), ("entity/hollow_walker/hurt2", lambda: walker_hurt(1.25))]),
    ("entity.hollow_walker.death", "Hollow Walker collapses", [("entity/hollow_walker/death", walker_death)]),
    ("entity.hollow_walker.attack", "Hollow Walker lunges", [("entity/hollow_walker/attack", walker_attack)]),

    ("entity.crawler.ambient", "Crawler clicks",
     [("entity/crawler/ambient1", lambda: crawler_ambient(1.6)), ("entity/crawler/ambient2", lambda: crawler_ambient(2.0))]),
    ("entity.crawler.hurt", "Crawler screeches", [("entity/crawler/hurt", lambda: crawler_screech(0.45, 900, 1500))]),
    ("entity.crawler.death", "Crawler gurgles", [("entity/crawler/death", crawler_death)]),
    ("entity.crawler.attack", "Crawler shrieks", [("entity/crawler/attack", lambda: crawler_screech(0.7, 700, 1900, 0.6))]),

    ("entity.stretched.ambient", "Something whispers",
     [("entity/stretched/ambient1", lambda: stretched_ambient(0)), ("entity/stretched/ambient2", lambda: stretched_ambient(1))]),
    ("entity.stretched.hurt", "The Stretched groans", [("entity/stretched/hurt", stretched_hurt)]),
    ("entity.stretched.death", "The Stretched exhales", [("entity/stretched/death", stretched_death)]),
    ("entity.stretched.step", "Bones creak",
     [("entity/stretched/step1", lambda: stretched_step(0)), ("entity/stretched/step2", lambda: stretched_step(1))]),
    ("entity.stretched.attack", "The Stretched lashes out", [("entity/stretched/attack", lambda: walker_attack() * 0.8)]),

    ("entity.echo_hound.ambient", "Echo Hound growls",
     [("entity/echo_hound/ambient1", lambda: hound_growl(1.4, 62)), ("entity/echo_hound/ambient2", lambda: hound_growl(1.1, 74))]),
    ("entity.echo_hound.hurt", "Echo Hound yelps", [("entity/echo_hound/hurt", hound_yelp)]),
    ("entity.echo_hound.death", "Echo Hound whines", [("entity/echo_hound/death", hound_death)]),
    ("entity.echo_hound.attack", "Echo Hound snarls", [("entity/echo_hound/attack", hound_bark)]),

    ("entity.remnant.ambient", "Remnant rings",
     [("entity/remnant/ambient1", lambda: remnant_ring(196)), ("entity/remnant/ambient2", lambda: remnant_ring(233))]),
    ("entity.remnant.hurt", "Remnant clanks", [("entity/remnant/hurt1", lambda: clank(0.45)), ("entity/remnant/hurt2", lambda: clank(0.35) * 0.9)]),
    ("entity.remnant.death", "Remnant collapses", [("entity/remnant/death", remnant_death)]),
    ("entity.remnant.attack", "Remnant swings", [("entity/remnant/attack", lambda: walker_attack() * 0.6 + clank(0.65)[:int(0.65 * SR)] * 0.0)]),

    ("fracture.rumble", "The sky rumbles", [("fracture/rumble", sky_rumble)]),
    ("fracture.crack", "The sky cracks", [("fracture/crack", sky_crack)]),
    ("fracture.glass", "Glass shatters", [("fracture/glass", glass_shatter)]),
    ("fracture.roar", "Something roars", [("fracture/roar", tentacle_roar)]),
    ("fracture.slither", "Something slithers", [("fracture/slither", tentacle_slither)]),
    ("fracture.pull", "You are pulled upward", [("fracture/pull", pull_whoosh)]),
    ("fracture.arrive", "A heavy silence settles", [("fracture/arrive", arrive_boom)]),

    ("ambient.sky_creak", "The sky creaks", [("ambient/sky_creak1", lambda: sky_creak(0)), ("ambient/sky_creak2", lambda: sky_creak(1))]),
    ("ambient.sky_whisper", "Whispers from above",
     [("ambient/sky_whisper1", lambda: whisper(0)), ("ambient/sky_whisper2", lambda: whisper(1)), ("ambient/sky_whisper3", lambda: whisper(2))]),
    ("ambient.sky_scream", "A distant scream", [("ambient/sky_scream", distant_scream)]),
    ("ambient.whisper_far", "Distant whispers",
     [("ambient/whisper_far1", lambda: whisper(3, True)), ("ambient/whisper_far2", lambda: whisper(4, True)), ("ambient/whisper_far3", lambda: whisper(5, True))]),
    ("ambient.their_world", None, [("ambient/their_world", their_world_loop)]),
    ("ambient.heartbeat", None, [("ambient/heartbeat", heartbeat)]),

    ("block.memory_cache.open", "Memories are released", [("block/cache_open", cache_open)]),
    ("block.memory_cache.deny", "The memories are guarded", [("block/cache_deny", cache_deny)]),
]

STREAMED = {"ambient/their_world"}


def encode(path, x):
    x = np.clip(x, -1, 1)
    pcm = (x * 32767).astype(np.int16)
    out = ensure(os.path.join(ASSETS, "sounds", path + ".ogg"))
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        wavname = tmp.name
    with wave.open(wavname, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wavname, "-ac", "1", "-c:a", "libvorbis", "-q:a", "4", out], check=True)
    os.remove(wavname)
    return os.path.getsize(out)


def const_name(event):
    return event.upper().replace(".", "_")


def build_all():
    sounds_json = {}
    subtitles = {}
    total = 0
    for event, subtitle, files in EVENTS:
        entries = []
        for path, gen in files:
            size = encode(path, gen())
            total += size
            e = {"name": f"{MOD_ID}:{path}"}
            if path in STREAMED:
                e["stream"] = True
            entries.append(e if len(e) > 1 else e["name"])
        entry = {"sounds": entries}
        if subtitle:
            key = f"subtitles.{MOD_ID}.{event}"
            entry["subtitle"] = key
            subtitles[key] = subtitle
        sounds_json[event] = entry
    write_text(os.path.join(ASSETS, "sounds.json"), json.dumps(sounds_json, indent=2) + "\n")
    write_text(os.path.join(ASSETS, "lang", "_subtitles.json"), json.dumps(subtitles, indent=2) + "\n")

    lines = [f"package {PKG}.registry;", "",
             "import net.minecraft.core.Registry;", "import net.minecraft.core.registries.BuiltInRegistries;",
             "import net.minecraft.resources.ResourceLocation;", "import net.minecraft.sounds.SoundEvent;", "",
             f"import {PKG}.Thelostsouls;", "",
             "/** GENERATED by tools/sounds.py - one SoundEvent per entry in sounds.json. */",
             "public final class ModSounds {", "\tprivate ModSounds() {}", ""]
    for event, _s, _f in EVENTS:
        lines.append(f'\tpublic static final SoundEvent {const_name(event)} = register("{event}");')
    lines += ["", "\tprivate static SoundEvent register(String name) {",
              "\t\tResourceLocation id = Thelostsouls.id(name);",
              "\t\treturn Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));",
              "\t}", "", "\t/** Call once from the mod initializer so the static fields above get registered. */",
              "\tpublic static void init() {}", "}", ""]
    write_text(os.path.join(JAVA_MAIN, "registry", "ModSounds.java"), "\n".join(lines))
    print(f"  {sum(len(f) for _, _, f in EVENTS)} sound files, {len(EVENTS)} events, {total / 1024:.0f} KiB total")


if __name__ == "__main__":
    build_all()
