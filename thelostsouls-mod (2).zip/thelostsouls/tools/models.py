"""
Creature models: part definitions -> (1) Java model classes, (2) body textures, (3) glow textures.

Units are Minecraft model pixels (16 px = 1 block). y points DOWN and y=24 is the ground,
exactly like vanilla entity models. Cube dimensions must be integers (UV math).

Hand-tunable pose code lives in the *_ANIM strings below (it is copied into each model's
setupAnim). Part names become camelCase fields, e.g. "left_arm" -> this.leftArm.
"""
from common import *


class Part:
    def __init__(self, name, parent, pivot, cube, kind, rot=(0.0, 0.0, 0.0)):
        self.name, self.parent, self.pivot, self.cube, self.kind, self.rot = name, parent, pivot, cube, kind, rot
        self.uv = None

    @property
    def w(self): return int(self.cube[3])
    @property
    def h(self): return int(self.cube[4])
    @property
    def d(self): return int(self.cube[5])
    @property
    def fw(self): return 2 * (self.d + self.w)
    @property
    def fh(self): return self.d + self.h

    def faces(self):
        u, v = self.uv
        w, h, d = self.w, self.h, self.d
        return {
            "top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d),
            "right": (u, v + d, d, h), "front": (u + d, v + d, w, h),
            "left": (u + d + w, v + d, d, h), "back": (u + 2 * d + w, v + d, w, h),
        }


def camel(s):
    p = s.split("_")
    return p[0] + "".join(x.title() for x in p[1:])


def jf(x):
    return repr(float(x)) + "F"


def pack(parts, sizes=((64, 64), (64, 96), (64, 128), (128, 128))):
    for (W, H) in sizes:
        order = sorted(parts, key=lambda p: (-p.fh, -p.fw))
        x = y = shelf = 0
        ok = True
        for p in order:
            if x + p.fw > W:
                x, y, shelf = 0, y + shelf, 0
            if y + p.fh > H:
                ok = False
                break
            p.uv = (x, y)
            x += p.fw
            shelf = max(shelf, p.fh)
        if ok:
            return W, H
    raise RuntimeError("model does not fit in any texture size")


# ----------------------------------------------------------------------------------------
# Part definitions
# ----------------------------------------------------------------------------------------
def walker_parts():
    return [
        Part("body", None, (0, 10, 0), (-4, -14, -2, 8, 14, 4), "skin"),
        Part("neck", "body", (0, -14, 0), (-1.5, -5, -1.5, 3, 5, 3), "skin"),
        Part("head", "neck", (0, -4, 0), (-4, -6, -4, 8, 6, 8), "skin"),
        Part("jaw", "head", (0, -1, 3.5), (-3.5, 0, -7, 7, 3, 7), "skin"),
        Part("left_arm", "body", (5.5, -12, 0), (-1.5, -1, -1.5, 3, 17, 3), "skin"),
        Part("right_arm", "body", (-5.5, -12, 0), (-1.5, -1, -1.5, 3, 17, 3), "skin"),
        Part("left_stump", "body", (5.5, -12, 0), (-1.5, -1, -1.5, 3, 5, 3), "stump"),
        Part("right_stump", "body", (-5.5, -12, 0), (-1.5, -1, -1.5, 3, 5, 3), "stump"),
        Part("left_leg", None, (2, 10, 0), (-1.5, 0, -1.5, 3, 14, 3), "skin"),
        Part("right_leg", None, (-2, 10, 0), (-1.5, 0, -1.5, 3, 14, 3), "skin"),
        Part("left_leg_stump", None, (2, 10, 0), (-1.5, 0, -1.5, 3, 5, 3), "stump"),
        Part("right_leg_stump", None, (-2, 10, 0), (-1.5, 0, -1.5, 3, 5, 3), "stump"),
        Part("ribs", "body", (0, -6, -2), (-3, -5, -1, 6, 8, 1), "ribs"),
        Part("extra_arm", "body", (0, -10, 2), (-1, 0, -1, 2, 14, 2), "skin", (2.5, 0.0, 0.25)),
        Part("head2", "body", (-5, -15, 0), (-2.5, -5, -2.5, 5, 5, 5), "skin", (0.0, 0.0, -0.5)),
    ]


def crawler_parts():
    return [
        Part("body", None, (0, 19, 0), (-4, -3, -6, 8, 5, 12), "skin"),
        Part("waist", "body", (0, 0, 6), (-3, -2, 0, 6, 4, 3), "stump"),
        Part("spine1", "waist", (0, 0, 3), (-0.5, -0.5, 0, 1, 1, 4), "bone"),
        Part("spine2", "spine1", (0, 0, 4), (-0.5, -0.5, 0, 1, 1, 4), "bone"),
        Part("spine3", "spine2", (0, 0, 4), (-0.5, -0.5, 0, 1, 1, 4), "bone"),
        Part("head", "body", (0, -1, -6), (-3, -3, -6, 6, 6, 6), "skin"),
        Part("jaw", "head", (0, 2, -1), (-2.5, 0, -5, 5, 2, 5), "skin"),
        Part("left_arm", "body", (4.5, -1, -4), (-1.5, 0, -1.5, 3, 15, 3), "skin"),
        Part("right_arm", "body", (-4.5, -1, -4), (-1.5, 0, -1.5, 3, 15, 3), "skin"),
        Part("left_stump", "body", (4.5, -1, -4), (-1.5, 0, -1.5, 3, 5, 3), "stump"),
        Part("right_stump", "body", (-4.5, -1, -4), (-1.5, 0, -1.5, 3, 5, 3), "stump"),
        Part("extra_arm", "body", (0, -3, -1), (-1.5, 0, -1.5, 3, 13, 3), "skin", (-1.0, 0.0, 0.0)),
        Part("back_ribs", "body", (0, -3, 0), (-3, -1, -4, 6, 1, 8), "ribs"),
    ]


def stretched_parts():
    return [
        Part("body", None, (0, 2, 0), (-3, -18, -1.5, 6, 18, 3), "skin"),
        Part("neck", "body", (0, -18, 0), (-1, -6, -1, 2, 6, 2), "skin"),
        Part("head", "neck", (0, -5, 0), (-2.5, -7, -2.5, 5, 7, 5), "skin"),
        Part("left_arm", "body", (4, -17, 0), (-1, -1, -1, 2, 28, 2), "skin"),
        Part("right_arm", "body", (-4, -17, 0), (-1, -1, -1, 2, 28, 2), "skin"),
        Part("left_hand", "left_arm", (0, 27, 0), (-1.5, 0, -1, 3, 7, 2), "skin"),
        Part("right_hand", "right_arm", (0, 27, 0), (-1.5, 0, -1, 3, 7, 2), "skin"),
        Part("left_stump", "body", (4, -17, 0), (-1, -1, -1, 2, 6, 2), "stump"),
        Part("right_stump", "body", (-4, -17, 0), (-1, -1, -1, 2, 6, 2), "stump"),
        Part("left_leg", None, (1.5, 2, 0), (-1, 0, -1, 2, 22, 2), "skin"),
        Part("right_leg", None, (-1.5, 2, 0), (-1, 0, -1, 2, 22, 2), "skin"),
        Part("ribs", "body", (0, -12, -1.5), (-2, -5, -1, 4, 10, 1), "ribs"),
        Part("extra_arm_a", "body", (3, -8, 1.5), (-0.5, 0, -0.5, 1, 20, 1), "skin", (0.3, 0.0, 0.2)),
        Part("extra_arm_b", "body", (-3, -8, 1.5), (-0.5, 0, -0.5, 1, 20, 1), "skin", (0.3, 0.0, -0.2)),
    ]


def hound_parts():
    return [
        Part("body", None, (0, 14, 0), (-3, -3, -7, 6, 6, 14), "fur"),
        Part("head", "body", (0, -2, -7), (-3, -3, -5, 6, 6, 5), "mask"),
        Part("snout", "head", (0, 1, -5), (-1.5, -1, -4, 3, 3, 4), "mask"),
        Part("jaw", "head", (0, 2.5, -4), (-1.5, 0, -4, 3, 1, 4), "mask"),
        Part("left_ear", "head", (2, -3, -1), (-1, -3, -0.5, 2, 3, 1), "fur"),
        Part("right_ear", "head", (-2, -3, -1), (-1, -3, -0.5, 2, 3, 1), "fur"),
        Part("front_left_leg", "body", (2, 3, -5), (-1, 0, -1, 2, 7, 2), "fur"),
        Part("front_right_leg", "body", (-2, 3, -5), (-1, 0, -1, 2, 7, 2), "fur"),
        Part("back_left_leg", "body", (2, 3, 5), (-1, 0, -1, 2, 7, 2), "fur"),
        Part("back_right_leg", "body", (-2, 3, 5), (-1, 0, -1, 2, 7, 2), "fur"),
        Part("tail", "body", (0, -2, 7), (-1, 0, 0, 2, 2, 8), "fur", (-0.6, 0.0, 0.0)),
    ]


def remnant_parts():
    return [
        Part("body", None, (0, 12, 0), (-4, -12, -2, 8, 12, 4), "metal"),
        Part("head", "body", (0, -12, 0), (-4, -8, -4, 8, 8, 8), "metal"),
        Part("left_arm", "body", (5, -10, 0), (-2, -2, -2, 4, 12, 4), "metal"),
        Part("right_arm", "body", (-5, -10, 0), (-2, -2, -2, 4, 12, 4), "metal"),
        Part("left_leg", None, (2, 12, 0), (-2, 0, -2, 4, 12, 4), "dark"),
        Part("right_leg", None, (-2, 12, 0), (-2, 0, -2, 4, 12, 4), "dark"),
        Part("blade", "right_arm", (0, 10, 0), (-0.5, 0, -1.5, 1, 18, 3), "blade"),
        Part("cape", "body", (0, -11, 2), (-4, 0, 0, 8, 16, 1), "cloth"),
    ]


# ----------------------------------------------------------------------------------------
# Pose code (copied into setupAnim).  Positive xRot on an "upward" part leans it FORWARD,
# negative xRot on a "downward" limb swings it forward (zombie arms = -PI/2).
# ----------------------------------------------------------------------------------------
WALKER_ANIM = """
		boolean noArmL = entity.hasFeature(Deformity.MISSING_ARM_L);
		boolean noArmR = entity.hasFeature(Deformity.MISSING_ARM_R);
		boolean noLeg = entity.hasFeature(Deformity.MISSING_LEG);
		float deg = (float) Math.PI / 180.0F;
		float swing = limbSwing * 0.5F;
		float amt = limbSwingAmount;

		this.leftArm.visible = !noArmL;
		this.leftStump.visible = noArmL;
		this.rightArm.visible = !noArmR;
		this.rightStump.visible = noArmR;
		this.leftLeg.visible = !noLeg;
		this.leftLegStump.visible = noLeg;
		this.rightLegStump.visible = false;
		this.ribs.visible = entity.hasFeature(Deformity.RIBS);
		this.extraArm.visible = entity.hasFeature(Deformity.EXTRA_ARM);
		this.head2.visible = entity.hasFeature(Deformity.SECOND_HEAD);

		// stooped, lurching gait; a missing leg makes the whole body list to one side
		this.body.xRot = 0.18F + 0.10F * amt + 0.03F * Mth.sin(ageInTicks * 0.07F);
		this.body.yRot = Mth.cos(swing) * 0.15F * amt;
		this.body.zRot = noLeg ? 0.30F + 0.06F * Mth.sin(swing) * amt : 0.04F * Mth.sin(swing) * amt;

		this.leftLeg.xRot = Mth.cos(swing) * 1.1F * amt;
		this.rightLeg.xRot = Mth.cos(swing + Mth.PI) * 1.1F * amt * (noLeg ? 0.7F : 1.0F);
		this.leftLegStump.xRot = Mth.cos(swing) * 0.5F * amt;

		float sway = 0.05F * Mth.sin(ageInTicks * 0.09F);
		this.leftArm.xRot = Mth.cos(swing + Mth.PI) * 0.7F * amt + sway;
		this.leftArm.zRot = -0.06F - 0.05F * amt;
		this.rightArm.xRot = Mth.cos(swing) * 0.7F * amt - sway;
		this.rightArm.zRot = 0.06F + 0.05F * amt;
		this.leftStump.xRot = this.leftArm.xRot;
		this.leftStump.zRot = this.leftArm.zRot;
		this.rightStump.xRot = this.rightArm.xRot;
		this.rightStump.zRot = this.rightArm.zRot;

		// the neck cranes forward, the head lolls to one side
		this.neck.xRot = 0.35F + 0.10F * amt;
		this.head.yRot = netHeadYaw * deg * 0.6F;
		this.head.xRot = headPitch * deg * 0.5F + 0.25F;
		this.head.zRot = 0.28F + 0.05F * Mth.sin(ageInTicks * 0.13F);
		this.jaw.xRot = entity.hasFeature(Deformity.HANGING_JAW)
				? 0.95F + 0.08F * Mth.sin(ageInTicks * 0.2F)
				: 0.12F + 0.06F * Mth.sin(ageInTicks * 0.31F);
		this.extraArm.xRot = 2.5F + 0.15F * Mth.sin(ageInTicks * 0.35F);
		this.extraArm.zRot = 0.25F + 0.10F * Mth.sin(ageInTicks * 0.27F);
		this.head2.zRot = -0.5F + 0.15F * Mth.sin(ageInTicks * 0.5F);
		this.head2.yRot = 0.3F * Mth.sin(ageInTicks * 0.19F);

		this.animate(entity.idleAnimationState, WalkerAnimations.IDLE, ageInTicks);
		this.animate(entity.attackAnimationState, WalkerAnimations.ATTACK, ageInTicks);
"""

CRAWLER_ANIM = """
		boolean noArmL = entity.hasFeature(Deformity.MISSING_ARM_L);
		boolean noArmR = entity.hasFeature(Deformity.MISSING_ARM_R);
		float deg = (float) Math.PI / 180.0F;
		float swing = limbSwing * 0.8F;
		float amt = Math.min(1.0F, limbSwingAmount * 1.4F);

		this.leftArm.visible = !noArmL;
		this.leftStump.visible = noArmL;
		this.rightArm.visible = !noArmR;
		this.rightStump.visible = noArmR;
		this.extraArm.visible = entity.hasFeature(Deformity.EXTRA_ARM);
		this.backRibs.visible = entity.hasFeature(Deformity.RIBS);

		// dragging the torso along the ground with the arms
		this.body.y += Mth.sin(swing * 2.0F) * 0.8F * amt;
		this.body.xRot = -0.08F * amt + 0.03F * Mth.sin(ageInTicks * 0.11F);
		this.body.zRot = Mth.cos(swing) * 0.08F * amt + (noArmL != noArmR ? 0.15F : 0.0F);

		this.leftArm.xRot = -1.55F + Mth.cos(swing) * 0.9F * amt + 0.05F * Mth.sin(ageInTicks * 0.1F);
		this.rightArm.xRot = -1.55F + Mth.cos(swing + Mth.PI) * 0.9F * amt - 0.05F * Mth.sin(ageInTicks * 0.1F);
		this.leftArm.zRot = -0.25F;
		this.rightArm.zRot = 0.25F;
		this.leftStump.xRot = this.leftArm.xRot;
		this.leftStump.zRot = this.leftArm.zRot;
		this.rightStump.xRot = this.rightArm.xRot;
		this.rightStump.zRot = this.rightArm.zRot;
		this.extraArm.xRot = -1.0F + 0.5F * Mth.sin(ageInTicks * 0.3F);

		this.head.xRot = headPitch * deg - 0.25F;
		this.head.yRot = netHeadYaw * deg;
		this.head.zRot = 0.2F * Mth.sin(ageInTicks * 0.31F);
		this.jaw.xRot = entity.hasFeature(Deformity.HANGING_JAW)
				? 1.1F
				: 0.25F + 0.22F * Mth.sin(ageInTicks * 0.4F);

		// the spinal column trails behind, whipping from side to side
		float w = ageInTicks * 0.15F + swing;
		this.spine1.yRot = Mth.sin(w) * 0.5F * (0.3F + amt);
		this.spine2.yRot = Mth.sin(w - 1.0F) * 0.6F * (0.3F + amt);
		this.spine3.yRot = Mth.sin(w - 2.0F) * 0.7F * (0.3F + amt);

		this.animate(entity.idleAnimationState, CrawlerAnimations.IDLE, ageInTicks);
		this.animate(entity.attackAnimationState, CrawlerAnimations.ATTACK, ageInTicks);
"""

STRETCHED_ANIM = """
		boolean observed = entity.isObserved();
		boolean noArmL = entity.hasFeature(Deformity.MISSING_ARM_L);
		boolean noArmR = entity.hasFeature(Deformity.MISSING_ARM_R);
		float deg = (float) Math.PI / 180.0F;
		float swing = limbSwing * 0.45F;
		float amt = observed ? 0.0F : limbSwingAmount;
		boolean extra = entity.hasFeature(Deformity.EXTRA_ARM);

		this.leftArm.visible = !noArmL;
		this.leftHand.visible = !noArmL;
		this.leftStump.visible = noArmL;
		this.rightArm.visible = !noArmR;
		this.rightHand.visible = !noArmR;
		this.rightStump.visible = noArmR;
		this.ribs.visible = entity.hasFeature(Deformity.RIBS);
		this.extraArmA.visible = extra;
		this.extraArmB.visible = extra;

		this.leftLeg.xRot = Mth.cos(swing) * 0.9F * amt;
		this.rightLeg.xRot = Mth.cos(swing + Mth.PI) * 0.9F * amt;
		this.body.xRot = observed ? 0.0F : 0.10F * amt + 0.04F * Mth.sin(ageInTicks * 0.05F);

		// frozen and rigid while watched, loose and flailing when not
		float sway = observed ? 0.0F : 0.05F * Mth.sin(ageInTicks * 0.05F);
		this.leftArm.xRot = Mth.cos(swing + Mth.PI) * 0.6F * amt + sway;
		this.rightArm.xRot = Mth.cos(swing) * 0.6F * amt - sway;
		this.leftArm.zRot = observed ? -0.02F : -0.08F - 0.10F * amt;
		this.rightArm.zRot = observed ? 0.02F : 0.08F + 0.10F * amt;
		this.leftStump.xRot = this.leftArm.xRot;
		this.leftStump.zRot = this.leftArm.zRot;
		this.rightStump.xRot = this.rightArm.xRot;
		this.rightStump.zRot = this.rightArm.zRot;
		this.leftHand.xRot = observed ? 0.0F : 0.35F * Mth.sin(ageInTicks * 0.4F);
		this.rightHand.xRot = observed ? 0.0F : 0.35F * Mth.sin(ageInTicks * 0.4F + 1.7F);
		this.extraArmA.xRot = 0.3F + (observed ? 0.0F : 0.3F * Mth.sin(ageInTicks * 0.23F));
		this.extraArmB.xRot = 0.3F + (observed ? 0.0F : 0.3F * Mth.sin(ageInTicks * 0.23F + 2.0F));

		this.neck.xRot = observed ? 0.05F : 0.20F + 0.05F * Mth.sin(ageInTicks * 0.07F);
		this.head.yRot = netHeadYaw * deg * 0.8F;
		this.head.xRot = headPitch * deg * 0.6F;
		this.head.zRot = observed ? 0.45F : 0.08F * Mth.sin(ageInTicks * 0.11F);

		this.animate(entity.idleAnimationState, StretchedAnimations.IDLE, ageInTicks);
		this.animate(entity.attackAnimationState, StretchedAnimations.ATTACK, ageInTicks);
"""

HOUND_ANIM = """
		float deg = (float) Math.PI / 180.0F;
		float swing = limbSwing * 0.9F;
		float amt = limbSwingAmount;

		this.frontLeftLeg.xRot = Mth.cos(swing) * 1.4F * amt;
		this.backRightLeg.xRot = Mth.cos(swing) * 1.4F * amt;
		this.frontRightLeg.xRot = Mth.cos(swing + Mth.PI) * 1.4F * amt;
		this.backLeftLeg.xRot = Mth.cos(swing + Mth.PI) * 1.4F * amt;

		this.body.y += -Math.abs(Mth.sin(swing)) * 1.2F * amt;
		this.head.xRot = headPitch * deg + 0.2F;
		this.head.yRot = netHeadYaw * deg;
		this.jaw.xRot = 0.15F + 0.1F * Mth.sin(ageInTicks * 0.3F);
		this.tail.xRot = -0.6F + 0.15F * Mth.sin(ageInTicks * 0.2F);
		this.tail.yRot = 0.5F * Mth.sin(ageInTicks * 0.25F + swing);
		this.leftEar.zRot = 0.3F + 0.15F * Mth.sin(ageInTicks * 0.4F);
		this.rightEar.zRot = -0.3F - 0.15F * Mth.sin(ageInTicks * 0.4F + 1.0F);

		this.animate(entity.idleAnimationState, EchoHoundAnimations.IDLE, ageInTicks);
		this.animate(entity.attackAnimationState, EchoHoundAnimations.ATTACK, ageInTicks);
"""

REMNANT_ANIM = """
		float deg = (float) Math.PI / 180.0F;
		float swing = limbSwing * 0.6F;
		float amt = limbSwingAmount;

		this.leftLeg.xRot = Mth.cos(swing) * 1.0F * amt;
		this.rightLeg.xRot = Mth.cos(swing + Mth.PI) * 1.0F * amt;
		this.body.xRot = 0.08F * amt;
		this.head.yRot = netHeadYaw * deg;
		this.head.xRot = headPitch * deg;

		this.leftArm.xRot = Mth.cos(swing + Mth.PI) * 0.8F * amt;
		this.leftArm.zRot = -0.05F;
		// the sword arm is held ready, always slightly raised
		this.rightArm.xRot = -0.55F + Mth.cos(swing) * 0.3F * amt;
		this.rightArm.zRot = 0.05F;
		this.cape.xRot = 0.08F + 0.45F * amt + 0.04F * Mth.sin(ageInTicks * 0.12F);

		this.animate(entity.idleAnimationState, RemnantAnimations.IDLE, ageInTicks);
		this.animate(entity.attackAnimationState, RemnantAnimations.ATTACK, ageInTicks);
"""

JAVA_TMPL = """package thelostsoulsyeyeye.client.model;

import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import thelostsoulsyeyeye.entity.Deformity;
import thelostsoulsyeyeye.entity.__ENTITY__;

/**
 * __DOC__
 *
 * The mesh and UV layout (createBodyLayer + constructor) are generated by tools/models.py so they
 * always match the generated texture. The pose code in setupAnim lives in tools/models.py as well
 * (copy your edits back there if you re-run the generator).
 */
public class __CLASS__ extends HierarchicalModel<__ENTITY__> {
	private final ModelPart root;
__FIELDS__

	public __CLASS__(ModelPart root) {
		this.root = root;
__CTOR__
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
__LAYER__
		return LayerDefinition.create(mesh, __W__, __H__);
	}

	@Override
	public ModelPart root() {
		return this.root;
	}

	@Override
	public void setupAnim(__ENTITY__ entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		this.root().getAllParts().forEach(ModelPart::resetPose);
__ANIM__
	}
}
"""


def emit_java(cls, entity, doc, parts, W, H, anim):
    fields = "\n".join(f"\tprivate final ModelPart {camel(p.name)};" for p in parts)
    ctor = []
    for p in parts:
        src = "root" if p.parent is None else "this." + camel(p.parent)
        ctor.append(f'\t\tthis.{camel(p.name)} = {src}.getChild("{p.name}");')
    layer = []
    for p in parts:
        parent = "root" if p.parent is None else camel(p.parent)
        ox, oy, oz, w, h, d = p.cube
        u, v = p.uv
        px, py, pz = p.pivot
        rx, ry, rz = p.rot
        if rx or ry or rz:
            pose = f"PartPose.offsetAndRotation({jf(px)}, {jf(py)}, {jf(pz)}, {jf(rx)}, {jf(ry)}, {jf(rz)})"
        else:
            pose = f"PartPose.offset({jf(px)}, {jf(py)}, {jf(pz)})"
        layer.append(
            f'\t\tPartDefinition {camel(p.name)} = {parent}.addOrReplaceChild("{p.name}", '
            f"CubeListBuilder.create().texOffs({u}, {v}).addBox({jf(ox)}, {jf(oy)}, {jf(oz)}, {jf(w)}, {jf(h)}, {jf(d)}), {pose});"
        )
    text = (JAVA_TMPL.replace("__ENTITY__", entity).replace("__CLASS__", cls).replace("__DOC__", doc)
            .replace("__FIELDS__", fields).replace("__CTOR__", "\n".join(ctor))
            .replace("__LAYER__", "\n".join(layer)).replace("__W__", str(W)).replace("__H__", str(H))
            .replace("__ANIM__", anim.strip("\n")))
    write_text(os.path.join(JAVA_CLIENT, "model", cls + ".java"), text)


# ----------------------------------------------------------------------------------------
# Texture painting
# ----------------------------------------------------------------------------------------
SHADE = {"top": 1.10, "bottom": 0.62, "right": 0.92, "front": 1.0, "left": 0.88, "back": 0.80}


def noise_rect(img, rect, base, var, rng, shade=1.0):
    x, y, w, h = rect
    if w <= 0 or h <= 0:
        return
    n = rng.normal(0, var, (h, w, 1))
    b = (fbm(h, w, rng, base_cell=6, octaves=2) - 0.5) * var * 2.2
    arr = np.array(base, dtype=np.float32)[None, None, :] * shade + n + b[..., None]
    patch = Image.fromarray(clamp8(arr)).convert("RGBA")
    img.paste(patch, (x, y))


def on_rect(img, rect, fn):
    """Draw inside a face rectangle only (never bleeds into neighbouring faces)."""
    x, y, w, h = rect
    tmp = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    fn(ImageDraw.Draw(tmp), w, h)
    img.paste(tmp, (x, y), tmp)


def splats(rng, n, color, rmin=1, rmax=2, drips=True):
    def fn(dr, w, h):
        for _ in range(n):
            cx, cy = int(rng.integers(0, w)), int(rng.integers(0, h))
            r = int(rng.integers(rmin, rmax + 1))
            dr.ellipse([cx - r, cy - max(1, int(r * 0.8)), cx + r, cy + max(1, int(r * 0.8))], fill=color)
            if drips and rng.random() < 0.7:
                ln = int(rng.integers(2, 8))
                dr.line([cx, cy, cx, min(h, cy + ln)], fill=color)
    return fn


def veins(rng, n, color):
    def fn(dr, w, h):
        for _ in range(n):
            x, y = int(rng.integers(0, w)), int(rng.integers(0, h))
            for _s in range(int(rng.integers(3, 9))):
                dr.point((x, y), fill=color)
                x += int(rng.integers(-1, 2))
                y += 1
    return fn


def paint_part(img, p, pal, rng, blood=0.6):
    f = p.faces()
    kind = p.kind
    base, var = pal[kind]
    for name, rect in f.items():
        noise_rect(img, rect, base, var, rng, SHADE[name])
    sides = [f["right"], f["front"], f["left"], f["back"]]
    if kind == "skin":
        for r in sides:
            area = r[2] * r[3]
            on_rect(img, r, veins(rng, max(1, area // 30), pal["vein"] + (255,)))
            if rng.random() < 0.6:
                on_rect(img, r, splats(rng, 1, pal["bruise"] + (190,), 1, 2, drips=False))
            if rng.random() < blood:
                on_rect(img, r, splats(rng, int(rng.integers(1, 4)), (118, 10, 14, 255), 1, 2))
    elif kind == "stump":
        for r in sides:
            x, y, w, h = r
            for yy in range(h):
                t = yy / max(1, h - 1)
                if t > 0.45:
                    a = min(1.0, (t - 0.45) / 0.4)
                    for xx in range(w):
                        c = img.getpixel((x + xx, y + yy))
                        raw = (150 + int(rng.integers(-12, 12)), 18, 26)
                        img.putpixel((x + xx, y + yy), tuple(int(c[i] * (1 - a) + raw[i] * a) for i in range(3)) + (255,))
            on_rect(img, r, splats(rng, 1, (74, 6, 10, 255), 1, 1))
        bx, by, bw, bh = f["bottom"]
        noise_rect(img, f["bottom"], (150, 18, 26), 14, rng, 1.0)

        def bone(dr, w, h):
            cx, cy = w // 2, h // 2
            dr.rectangle([cx - 1, cy - 1, cx, cy], fill=(205, 196, 176, 255))
            dr.rectangle([cx - 2, cy - 2, cx + 1, cy + 1], outline=(78, 6, 10, 255))
        on_rect(img, f["bottom"], bone)
    elif kind == "ribs":
        def ribcage(dr, w, h):
            dr.rectangle([0, 0, w - 1, h - 1], fill=(72, 10, 14, 255))
            for yy in range(0, h, 2):
                dr.line([0, yy, w - 1, yy], fill=(206, 198, 178, 255))
            dr.line([w // 2, 0, w // 2, h - 1], fill=(170, 160, 140, 255))
        on_rect(img, f["front"], ribcage)
        on_rect(img, f["top"], lambda dr, w, h: dr.rectangle([0, 0, w, h], fill=(170, 24, 30, 255)))
        on_rect(img, f["front"], splats(rng, 2, (130, 12, 16, 255), 1, 1))
    elif kind == "bone":
        for r in sides:
            on_rect(img, r, veins(rng, 2, (110, 100, 86, 255)))
    elif kind == "cloth":
        for r in sides:
            def stripes(dr, w, h):
                for yy in range(1, h, 3):
                    dr.line([0, yy, w, yy], fill=tuple(int(c * 0.7) for c in base) + (255,))
                for _ in range(max(1, w // 2)):
                    dr.point((int(rng.integers(0, w)), h - 1), fill=(0, 0, 0, 0))
            on_rect(img, r, stripes)
    elif kind in ("metal", "dark", "blade"):
        for r in sides:
            on_rect(img, r, splats(rng, int(rng.integers(1, 3)), (112, 64, 34, 220), 1, 2, drips=False))
            on_rect(img, r, veins(rng, 2, (40, 44, 54, 255)))
    elif kind in ("fur", "mask"):
        for r in sides:
            on_rect(img, r, veins(rng, max(1, (r[2] * r[3]) // 14), tuple(min(255, int(c * 1.9)) for c in base) + (255,)))


def face_px(img, part, face, pts, color):
    x, y, w, h = part.faces()[face]
    for (px, py) in pts:
        if 0 <= px < w and 0 <= py < h:
            img.putpixel((x + px, y + py), color)


def build_entity(name, parts, pal, decorate, blood=0.6, seed=1):
    W, H = pack(parts)
    rng = np.random.default_rng(seed)
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 255))
    for p in parts:
        paint_part(img, p, pal, rng, blood)
    P = {p.name: p for p in parts}
    decorate(img, glow, P, rng)
    save_png(img, f"entity/{name}.png")
    save_png(glow, f"entity/{name}_glow.png")
    return W, H


# --- per-creature decoration (faces, eyes, glow) ------------------------------------------
def deco_walker(img, glow, P, rng):
    head, jaw = P["head"], P["jaw"]
    # sunken sockets + pinprick glowing eyes, a crack across the forehead
    for (ex, ey) in ((1, 2), (5, 2)):
        face_px(img, head, "front", [(ex, ey), (ex + 1, ey), (ex, ey + 1), (ex + 1, ey + 1)], (14, 8, 14, 255))
    face_px(glow, head, "front", [(2, 3), (5, 3)], (255, 236, 160, 255))
    face_px(glow, head, "front", [(2, 2), (6, 2)], (120, 96, 40, 255))
    face_px(img, head, "front", [(3, 0), (4, 1), (3, 2), (4, 3)], (40, 20, 30, 255))
    # jaw: ragged teeth on a dark red gullet
    jf_ = jaw.faces()["front"]
    for xx in range(jf_[2]):
        img.putpixel((jf_[0] + xx, jf_[1]), (206, 198, 178, 255) if xx % 2 == 0 else (60, 8, 12, 255))
    face_px(glow, jaw, "top", [(2, 3), (3, 3), (4, 3)], (90, 0, 0, 255))
    face_px(glow, P["ribs"], "front", [(1, 3), (4, 5)], (150, 40, 20, 255))


def deco_crawler(img, glow, P, rng):
    head = P["head"]
    # huge blank eyes
    face_px(img, head, "front", [(0, 2), (1, 2), (0, 3), (1, 3), (4, 2), (5, 2), (4, 3), (5, 3)], (214, 210, 200, 255))
    face_px(glow, head, "front", [(0, 2), (1, 2), (0, 3), (1, 3), (4, 2), (5, 2), (4, 3), (5, 3)], (210, 210, 235, 255))
    face_px(img, head, "front", [(1, 3), (4, 3)], (10, 10, 10, 255))
    face_px(glow, head, "front", [(1, 3), (4, 3)], (0, 0, 0, 255))
    jf_ = P["jaw"].faces()["front"]
    for xx in range(jf_[2]):
        img.putpixel((jf_[0] + xx, jf_[1]), (206, 198, 178, 255) if xx % 2 else (60, 8, 12, 255))
    face_px(glow, P["waist"], "back", [(1, 1), (4, 2)], (170, 20, 20, 255))


def deco_stretched(img, glow, P, rng):
    head = P["head"]
    # no eyes. Two shallow dimples and a long stitched smile.
    face_px(img, head, "front", [(1, 2), (3, 2)], (150, 146, 144, 255))
    face_px(img, head, "front", [(0, 4), (1, 4), (2, 4), (3, 4), (4, 4)], (52, 44, 48, 255))
    face_px(img, head, "front", [(0, 3), (2, 3), (4, 3), (0, 5), (2, 5), (4, 5)], (52, 44, 48, 255))
    face_px(glow, head, "front", [(1, 4), (2, 4), (3, 4)], (110, 0, 0, 255))
    face_px(glow, P["ribs"], "front", [(1, 4), (2, 6)], (130, 20, 20, 255))
    for h in ("left_hand", "right_hand"):
        x, y, w, hh = P[h].faces()["front"]
        for xx in (0, 2):
            for yy in range(3, hh):
                img.putpixel((x + xx, y + yy), (140, 136, 134, 255))


def deco_hound(img, glow, P, rng):
    head = P["head"]
    face_px(img, head, "front", [(0, 2), (1, 2), (4, 2), (5, 2)], (6, 8, 12, 255))
    face_px(glow, head, "front", [(0, 2), (1, 2), (4, 2), (5, 2)], (110, 230, 255, 255))
    face_px(glow, head, "front", [(2, 0), (3, 0)], (40, 100, 120, 255))
    face_px(glow, P["body"], "top", [(1, 3), (3, 7), (4, 10)], (60, 140, 170, 255))
    face_px(glow, P["body"], "left", [(2, 3), (5, 8)], (60, 140, 170, 255))
    face_px(glow, P["body"], "right", [(3, 4), (7, 9)], (60, 140, 170, 255))


def deco_remnant(img, glow, P, rng):
    head = P["head"]
    face_px(img, head, "front", [(x, y) for x in range(8) for y in (3, 4)], (8, 10, 14, 255))
    face_px(glow, head, "front", [(x, 3) for x in range(1, 7)], (110, 225, 255, 255))
    face_px(glow, head, "front", [(x, 4) for x in range(2, 6)], (50, 120, 150, 255))
    face_px(glow, P["body"], "front", [(3, 4), (4, 4), (3, 5), (4, 5)], (80, 190, 230, 255))
    blade = P["blade"]
    for fc in ("front", "back", "left", "right"):
        x, y, w, h = blade.faces()[fc]
        for yy in range(h):
            for xx in range(w):
                img.putpixel((x + xx, y + yy), (150 + (yy % 3) * 8, 160 + (yy % 3) * 8, 176, 255))
    face_px(glow, blade, "left", [(1, y) for y in range(1, 18, 3)], (60, 140, 170, 255))


PAL_WALKER = {"skin": ((118, 112, 122), 9), "stump": ((118, 112, 122), 9), "bone": ((200, 192, 172), 8),
              "ribs": ((200, 192, 172), 8), "vein": (70, 66, 100), "bruise": (92, 64, 96)}
PAL_CRAWLER = {"skin": ((92, 94, 100), 8), "stump": ((92, 94, 100), 8), "bone": ((196, 188, 168), 8),
               "ribs": ((196, 188, 168), 8), "vein": (60, 64, 96), "bruise": (70, 56, 84)}
PAL_STRETCHED = {"skin": ((208, 203, 198), 7), "stump": ((208, 203, 198), 7), "bone": ((204, 196, 178), 6),
                 "ribs": ((204, 196, 178), 6), "vein": (150, 142, 150), "bruise": (160, 150, 158)}
PAL_HOUND = {"fur": ((24, 26, 36), 6), "mask": ((184, 190, 202), 8), "bone": ((184, 190, 202), 8)}
PAL_REMNANT = {"metal": ((70, 76, 90), 7), "dark": ((34, 34, 44), 5), "cloth": ((58, 40, 62), 6),
               "blade": ((150, 160, 176), 6)}

ENTITIES = [
    ("hollow_walker", "HollowWalkerModel", "HollowWalkerEntity", "The Hollow Walker: a tall, stooped husk with a lolling head.",
     walker_parts, PAL_WALKER, deco_walker, WALKER_ANIM, 0.7, 11),
    ("crawler", "CrawlerModel", "CrawlerEntity", "The Crawler: legless, dragging its own spine behind it.",
     crawler_parts, PAL_CRAWLER, deco_crawler, CRAWLER_ANIM, 0.6, 12),
    ("stretched", "StretchedModel", "StretchedEntity", "The Stretched: too tall, too thin; stands perfectly still when watched.",
     stretched_parts, PAL_STRETCHED, deco_stretched, STRETCHED_ANIM, 0.3, 13),
    ("echo_hound", "EchoHoundModel", "EchoHoundEntity", "Echo Hound: a memory of something loyal, guarding the vaults.",
     hound_parts, PAL_HOUND, deco_hound, HOUND_ANIM, 0.0, 14),
    ("remnant", "RemnantModel", "RemnantEntity", "Remnant: an armoured memory bound to a vault.",
     remnant_parts, PAL_REMNANT, deco_remnant, REMNANT_ANIM, 0.0, 15),
]


def build_all():
    for (name, cls, ent, doc, parts_fn, pal, deco, anim, blood, seed) in ENTITIES:
        parts = parts_fn()
        W, H = build_entity(name, parts, pal, deco, blood, seed)
        emit_java(cls, ent, doc, parts, W, H, anim)
        print(f"  entity {name}: {len(parts)} parts, texture {W}x{H}")


if __name__ == "__main__":
    build_all()
