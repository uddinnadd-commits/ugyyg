#!/usr/bin/env python3
"""
Regenerates every generated asset in the mod. Run from anywhere:   python3 tools/build_assets.py

  models.py        creature textures + glow maps + client/model/*Model.java (mesh, UVs, pose code)
  env_textures.py  sky / tentacle / eye / shard / item / block / particle / HUD textures, mod icon
  sounds.py        all .ogg files, sounds.json, registry/ModSounds.java, subtitle strings
  data.py          dimension, worldgen, loot, advancements, recipes, models, blockstates, lang, fabric.mod.json

Needs: python3, numpy, scipy, Pillow, ffmpeg (with libvorbis).
"""
import models, env_textures, sounds, data

if __name__ == "__main__":
    print("creatures...")
    models.build_all()
    print("environment textures...")
    env_textures.build_all()
    print("sounds...")
    sounds.build_all()      # must run before data: it writes the subtitle strings data.lang() merges
    print("data...")
    data.build_all()
    print("done.")
