# The Lost Souls  (Fabric, Minecraft 1.20.1)

> Souls were guided into Minecraft with the promise of a palace to rest in.
> There is no palace. The sky is starting to crack.

A horror mod built on your `thelostsouls-template-1_20_1` template (same mod id `thelostsouls`, same
`thelostsoulsyeyeye` package, same Gradle setup; nothing in `build.gradle` / `gradle.properties` was changed).

## The loop

1. **The sky gets wrong.** Every player has a hidden countdown that only runs while they are under the Overworld sky
   (default 40 minutes; saved per player). As it fills, the sky is corrupted in stages: a sickly tint and closing fog,
   a **black sun and moon**, a network of **glowing cracks creeping out from one point**, a dark wound at its centre,
   an **Eye that opens and follows your gaze**, distant creaks, whispers and a far-off scream, and flickers.
2. **The Fracture.** When the countdown ends *and you can see the sky*, a ~14 s scripted event plays: the world
   rumbles, the sky **CRACKS** (white flash, camera jolt), **glass sky shards fly everywhere** (hundreds in the sky,
   plus particles raining on you), a **tentacle** (and two more) uncoils from the wound, your head is dragged up to look
   at it, it coils around you, you are **lifted into the sky** and the screen goes black.
3. **Their World.** You are dropped into a custom dimension at the same x/z: dirt, hills, bare twisted trees, thick
   fog, eternal dusk and a sky that is not real (breathing colours, marbled layers, the cracks from the other side,
   a black sun that never moves, a giant watching Eye, stars that flicker like dead pixels).
4. **They hunt you.** A director keeps Them spawning out of sight, already targeting you, and plays distant whispers.
   Your heartbeat gets louder and faster as one gets close.
5. **Memories.** Ruins of the souls' memories are scattered around: a child's room, a playground, a **waiting hall**
   with benches facing a painted-on "palace gate", an obelisk ringed by graves. Journals tell the story.
6. **Dungeons.** **Memory Vaults** hide underground. Their guardians are *not* Them (Echo Hounds, Remnants). Destroy the
   spawners and kill what they spawned, then open the **Memory Cache** for loot.
7. **Escape.** Dying sends you home. Every trip makes the next countdown 30% shorter (down to 25%): the sky remembers.

## The creatures

| Creature | Role | Notes |
|---|---|---|
| **Hollow Walker** | Them | tall, stooped, lolling head; lunges in short bursts of speed |
| **Crawler** | Them | legless, drags its own spine; leaps the last few blocks |
| **The Stretched** | Them | 3.4 blocks tall, no face; **freezes solid while any player looks at it**, sprints when nobody does |
| **Echo Hound** | dungeon | fast, cyan-glowing pack spawner guardian |
| **Remnant** | dungeon | armoured, sword arm, tough and hits hard |

Every one of **Them** rolls its own **deformities** when it spawns (synced to the client, saved): missing arms (raw
bloody stump), a missing leg (the whole body lists to one side), exposed ribs, a hanging jaw, an extra arm, a second
head on the shoulder. No two look alike. Each creature has its own keyframe **animation set** (idle twitches + attack),
procedural walk cycles, a separate **emissive glow layer** (eyes, wounds), and its own **voice** (ambient, hurt, death,
attack; the Stretched also has creaking-bone footsteps).

## Try it quickly

Use a creative world, difficulty **Easy or higher** (hostile mobs vanish on Peaceful).

```
/lostsouls progress 70      # sky at 70%: black sun, cracks, the Eye
/lostsouls fracture         # play the whole cinematic right now and get pulled in
/lostsouls enter            # skip the cinematic, go straight to Their World
/lostsouls leave            # come back to the Overworld spawn
/lostsouls reset            # wipe your progress and trip count
/gamerule lostSoulsFractureMinutes 3     # make the natural countdown 3 minutes (0 = event disabled)
/gamerule lostSoulsHunt false            # stop Them from spawning (for building / screenshots)
```

Creative tab **The Lost Souls** has spawn eggs for all five creatures, the Memory Cache block, Sky Shards, Memory
Fragments and the **Shardblade** (craft: 2 Sky Shards over 1 stick; slows the corrupted on hit).
Vaults are recognisable from the surface by a pair of broken blackstone pillars, one topped with a soul lantern, and a
stair trench running down between them.

## Build & run

Same as any Fabric project: `./gradlew build` (jar in `build/libs`), `./gradlew runClient` to play.
Requires Fabric API (already in your `build.gradle`).

## Where things live

```
src/main/java/thelostsoulsyeyeye/        common (server + client) code
  Thelostsouls.java                     entrypoint
  fracture/   FractureManager (countdown, cinematic script, teleport), FractureTimeline (shared tick table)
  world/      TheirWorld (dimension key, spawn finder), TheirWorldDirector (hunting), feature/ (structures + dungeon)
  entity/     CorruptedEntity base, 5 creatures, Deformity flags
  block/ item/ registry/ net/ data/ command/
src/client/java/thelostsoulsyeyeye/client/
  ClientFractureState   client-side timeline/state/sounds/camera shake/heartbeat
  render/     SkyEffects (overworld corruption + fog), TheirWorldSky, FractureCinematic (tentacles, shards), HudOverlay
  model/      generated creature models + hand-written keyframe animations
src/main/resources/data/thelostsouls/    dimension, dimension_type, biomes, noise settings, features, loot, advancements, recipe
src/main/resources/assets/thelostsouls/  textures, sounds, sounds.json, models, lang
tools/                                   generators + checkers (see below)
```

### Tuning knobs

* Countdown length: gamerule `lostSoulsFractureMinutes`; each trip shortens it (see `FractureManager.requiredTicks`).
* Cinematic timing: `fracture/FractureTimeline.java` (one table drives both server effects and client visuals).
* Hunting pressure: `TheirWorldDirector.hunt` (`desired` count, spawn distance, type weights).
* Dimension light: `fixed_time` in `data/.../dimension_type/their_world.json` (13000 = dusk; 18000 = midnight is much darker).
* Terrain: `data/.../worldgen/density_function/their_world/terrain.json` (hill height/scale), surface rule in `noise_settings`.
* Structure/dungeon frequency: `rarity_filter.chance` in `worldgen/placed_feature/*.json` (bigger number = rarer).
* Fog distance: `SkyEffects.applyFog`.

## The generators in `tools/`

Everything that is not hand-written Java (textures, sounds, creature model skeletons, `sounds.json`, `ModSounds.java`, all
the JSON) is produced by Python so it stays consistent:

```
python3 tools/build_assets.py     # regenerate everything (numpy, scipy, Pillow, ffmpeg+libvorbis)
python3 tools/check_integrity.py  # cross-reference check: sound constants, textures, registry ids, bones, lang keys
tools/syntax_check.sh             # javac parse pass over all Java (needs a JDK; ignores unresolved-symbol noise)
```

The creature models' mesh/UV layout and their `setupAnim` pose code live in `tools/models.py`. If you hand-edit a
`*Model.java` and later re-run the generator, copy your changes back into `tools/models.py` first (the generator overwrites).

## Honest status: what was and wasn't verified

I wrote this without the ability to launch Minecraft or download the game jars, so **it has not been compiled or
run**. What I did verify:

* all 58 Java files parse with `javac` (zero syntax errors);
* every JSON file is valid and every cross-reference resolves (`check_integrity.py`): sound constants vs `sounds.json`
  vs `.ogg` files, textures, registry ids, loot/advancement/item names, model parts vs animation bones, translation keys;
* all 50 sounds decode, are not silent/NaN/clipping, and the two loops are seamless;
* a handful of risky 1.20.1 APIs were checked against published mappings (`CommandSourceStack.sendSuccess` taking a
  `Supplier`, `SignText` / `SignBlockEntity.setText`), and I removed code that depended on signatures that changed in 1.20.2.

What may still need a tweak when you first build (all small, local fixes): a method name or parameter list in the
newer-in-1.20 APIs (`LootParams`, `GuiGraphics`, `BlockState.canBeReplaced()`, `SignBlockEntity.setWaxed`), and the
**worldgen JSON** (dimension / noise settings / biome): if the game rejects it, the world-creation log names the exact
file and field. The two things I would look at first if something looks off in game: the cinematic geometry in
`FractureCinematic` (tentacle/shard placement) and the sky layers' Fabric event timing in `SkyEffects`. Paste me the
build log or crash report and I'll fix it.
